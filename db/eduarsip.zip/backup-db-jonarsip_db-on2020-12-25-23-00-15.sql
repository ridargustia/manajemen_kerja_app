SET foreign_key_checks = 0;
#
# TABLE STRUCTURE FOR: arsip
#

DROP TABLE IF EXISTS `arsip`;

CREATE TABLE `arsip` (
  `id_arsip` int(11) NOT NULL AUTO_INCREMENT,
  `arsip_name` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `no_arsip` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gdrive_last_folder_name_target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `divisi_id` int(11) NOT NULL,
  `rak_id` int(11) NOT NULL,
  `baris_id` int(11) NOT NULL,
  `lokasi_id` int(11) NOT NULL DEFAULT 0,
  `box_id` int(11) NOT NULL,
  `map_id` int(11) NOT NULL,
  `deskripsi_arsip` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `keterangan` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `masa_retensi` date DEFAULT NULL,
  `status_retensi` tinyint(1) NOT NULL DEFAULT 1,
  `link_gdrive` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_file` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `is_available` int(11) NOT NULL DEFAULT 0,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_arsip`),
  KEY `FK_arsip_instansi` (`instansi_id`),
  KEY `FK_arsip_rak` (`rak_id`),
  KEY `FK_arsip_baris` (`baris_id`),
  KEY `FK_arsip_box` (`box_id`),
  KEY `FK_arsip_map` (`map_id`),
  KEY `FK_arsip_divisi` (`divisi_id`),
  KEY `FK_arsip_users` (`user_id`),
  KEY `FK_arsip_lokasi` (`lokasi_id`),
  CONSTRAINT `FK_arsip_baris` FOREIGN KEY (`baris_id`) REFERENCES `baris` (`id_baris`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_box` FOREIGN KEY (`box_id`) REFERENCES `box` (`id_box`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_divisi` FOREIGN KEY (`divisi_id`) REFERENCES `divisi` (`id_divisi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_lokasi` FOREIGN KEY (`lokasi_id`) REFERENCES `lokasi` (`id_lokasi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_map` FOREIGN KEY (`map_id`) REFERENCES `map` (`id_map`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_rak` FOREIGN KEY (`rak_id`) REFERENCES `rak` (`id_rak`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_users`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (2, 'SURAT PENETAPAN WALI AMANAH PBMT PERIODE 2020-2025', '005.1', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Surat penetapan wali amanah PBMT periode 2020-2025 # Munas ke 4 #  tahun 2020', '0', '2030-11-16', 1, NULL, 1, 3, 1, 'adminpbmt', '2020-12-17 07:49:27', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (3, 'SK  MURSIDA RAMBE', '005.2.1', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01/A/KPTS/WA/XI/2020 #Surat keputusan penetapan sebagai ketua umum Perhimpunan BMT Indonesia periode 2020-2025 ', '0', '2025-11-16', 1, NULL, 1, 3, 1, 'adminpbmt', '2020-12-17 08:44:29', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (6, 'SK M.BURHAN NASRUDDIN LATIEF', '005.2.2', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.01/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai sekretaris 1 pengurus MPP periode 2020-2025 ', '0', '2025-12-11', 1, NULL, 1, 3, 1, 'adminpbmt', '2020-12-17 13:31:39', 'adminpbmt', '2020-12-17 13:43:58', 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (7, 'lKANCqioadu', '1928419', 'wakpedwakyeng@gmail.com', 'MMJ', 4, 5, 5, 3, 3, 4, 3, 3, 'lacnaiowdu', '0', '2020-12-31', 1, NULL, 1, 7, 1, 'superadminmmj01', '2020-12-17 13:41:25', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (8, 'SK. DWI HASTUTI AMBAR WULANDARI', '005.2.3', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.02/KPTS/A/PBMT/XII/2020 # SK Dwi Hastuti Ambar Wulandari (ririn) sebagai sekretaris 2 pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 13:48:33', 'adminpbmt', '2020-12-17 14:24:32', 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (9, 'SK BUDI SANTOSO', '005.2.4', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK Budi Santoso sebagai bendahara 1 pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 13:51:22', 'adminpbmt', '2020-12-17 14:23:38', 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (10, 'JAscjklBQicu', '12401894', 'wakpedwakyeng@gmail.com', 'MMJ', 4, 5, 5, 3, 3, 4, 3, 3, 'aklsjcbnai', '0', '2020-12-30', 1, NULL, 1, 7, 1, 'administratormmj01', '2020-12-17 13:55:11', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (11, 'kasncao', '1250917490', 'wakpedwakyeng@gmail.com', 'MMJ', 4, 5, 6, 3, 3, 4, 3, 3, 'aALSCKo', '0', '2020-12-31', 1, NULL, 1, 9, 1, 'superadminmmj01', '2020-12-17 13:56:02', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (12, 'SK EKO PURNOMO', '005.2.5', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK Eko Purnomo sebagai bendahara 2 pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:22:49', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (13, 'SK FAISAL ABDUL HARIS', '005.2.6', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.05/KPTS/A/PBMT/XII/2020 # SK Faisal Abdul Haris sebagai ketua bidang internal pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:28:53', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (14, 'SK KHOIRIDIN', '005.2.7', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.06/KPTS/A/PBMT/XII/2020 # SK Khoiridin sebagai ketua bidang eksternal pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:41:33', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (15, 'SK RUSWANTO', '005.2.8', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.07/KPTS/A/PBMT/XII/2020 # SK Ruswanto sebagai ketua bidang kepatuhan dan akreditasi pengurus MPP periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:47:12', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (16, 'SK M.RIDWAN', '005.2.9', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.08/KPTS/A/PBMT/XII/2020 # SK M. Riwan sebagai Direktur PBMT Maal periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:51:29', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (17, 'SK IDA WIDIAHASTUTI', '005.2.10', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.09/KPTS/A/PBMT/XII/2020 # SK Ida Widiahastuti sebagai Direktur PBMT Taawun periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 14:55:00', 'adminpbmt', '2020-12-17 14:55:41', 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (18, 'SK KARTIKO ADI WIBOWO', '005.2.11', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.10/KPTS/A/PBMT/XII/2020 # SK Kartiko Adi Wibowo sebagai Direktur PBMT Institute periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 21:53:27', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (19, 'SK SAAT SUHARTO AMJAD', '005.2.12', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.11/KPTS/A/PBMT/XII/2020 # SK Saat Suharto Amjad sebagai Komisaris Utama PBMT Ventura periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 21:57:22', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (20, 'SK KHOIR KUSNANDAR', '005.2.13', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.12/KPTS/A/PBMT/XII/2020 # SK Khoir Kusnandar sebagai Direktur PBMT Rowasia periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 22:00:59', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (21, 'SK ASEP SUTISNA', '005.2.14', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 2, 2, 2, 2, 2, 2, 2, 'Nomor : 01.13/KPTS/A/PBMT/XII/2020 # SK Asep Sutisna sebagai Direktur PBMT Travel periode 2020-2025', '0', '2025-12-10', 1, NULL, 0, 3, 1, 'adminpbmt', '2020-12-17 22:03:29', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (23, 'tes besar', '43567', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 4, 4, 4, 4, 3, 4, 4, 'ya tes vps ', '1', '2020-12-31', 1, NULL, 1, 10, 1, 'adminmaal', '2020-12-25 08:16:15', '', NULL, 0, NULL, NULL);
INSERT INTO `arsip` (`id_arsip`, `arsip_name`, `no_arsip`, `email`, `gdrive_last_folder_name_target`, `instansi_id`, `cabang_id`, `divisi_id`, `rak_id`, `baris_id`, `lokasi_id`, `box_id`, `map_id`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `status_retensi`, `link_gdrive`, `status_file`, `user_id`, `is_available`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (24, 'asip tes', '233', 'arsippbmt@gmail.com', 'ARSIP PBMT', 2, 4, 4, 4, 4, 3, 4, 4, 'ytre', '1', '2020-12-25', 1, NULL, 1, 5, 1, 'jondhy', '2020-12-25 08:24:12', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: arsip_files
#

DROP TABLE IF EXISTS `arsip_files`;

CREATE TABLE `arsip_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `arsip_id` int(11) NOT NULL,
  `tokens_id` int(11) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gdrive_file_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gdrive_folder_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gdrive_file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (4, 6, 3, NULL, '', '1gfWcqj-JK8rThI8NC7OmXvLZn_ZimmkA', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1gfWcqj-JK8rThI8NC7OmXvLZn_ZimmkA/view?usp=drivesdk', 'assets/file_arsip/01._SK_M.BURHAN_N.L.pdf', '01._SK_M.BURHAN_N.L.pdf', '2020-12-17 13:31:39', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (5, 7, 4, NULL, '', '15iReeTXI0rhdyWSrM7B2Mm2E51kd8xTo', '1SaJuOSZp9Y_YUrmxRKPvq8H2_-OUjVuC', 'https://drive.google.com/file/d/15iReeTXI0rhdyWSrM7B2Mm2E51kd8xTo/view?usp=drivesdk', 'assets/file_arsip/64be5074bebbc708fc394cc29a577081.jpg', '64be5074bebbc708fc394cc29a577081.jpg', '2020-12-17 13:41:25', 'superadminmmj01');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (6, 8, 3, NULL, '', '1S9kHa9okygRNC8_SXOrGOSlCk9bpWxnJ', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1S9kHa9okygRNC8_SXOrGOSlCk9bpWxnJ/view?usp=drivesdk', 'assets/file_arsip/02._SK._DWI_HASTUTI_AMBAR_WULANDARI_(RIRIN).pdf', '02._SK._DWI_HASTUTI_AMBAR_WULANDARI_(RIRIN).pdf', '2020-12-17 13:48:33', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (7, 9, 3, NULL, '', '1v83zUK1evGoFYmTJNWufijzVTJ9OyJTO', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1v83zUK1evGoFYmTJNWufijzVTJ9OyJTO/view?usp=drivesdk', 'assets/file_arsip/03._SK_BUDI_SANTOSO.pdf', '03._SK_BUDI_SANTOSO.pdf', '2020-12-17 13:51:21', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (8, 10, 4, NULL, '', '1EVrf3IBNyTq23lVLbQKYG8JssfFwX9H2', '1SaJuOSZp9Y_YUrmxRKPvq8H2_-OUjVuC', 'https://drive.google.com/file/d/1EVrf3IBNyTq23lVLbQKYG8JssfFwX9H2/view?usp=drivesdk', 'assets/file_arsip/3477-silver-stripes-1920x1080-abstract-wallpaper.jpg', '3477-silver-stripes-1920x1080-abstract-wallpaper.jpg', '2020-12-17 13:55:08', 'administratormmj01');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (9, 10, 4, NULL, '', '1Z8pDJ12MDjK09_-QOr6wPbXn4cZv1sib', '1SaJuOSZp9Y_YUrmxRKPvq8H2_-OUjVuC', 'https://drive.google.com/file/d/1Z8pDJ12MDjK09_-QOr6wPbXn4cZv1sib/view?usp=drivesdk', 'assets/file_arsip/1914418.jpg', '1914418.jpg', '2020-12-17 13:55:11', 'administratormmj01');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (10, 11, 4, NULL, '', '1wNpfj6DCxxnN28JCQdRn8mqKFn2DLQRf', '1SaJuOSZp9Y_YUrmxRKPvq8H2_-OUjVuC', 'https://drive.google.com/file/d/1wNpfj6DCxxnN28JCQdRn8mqKFn2DLQRf/view?usp=drivesdk', 'assets/file_arsip/464468-underwater-1280x720.jpg', '464468-underwater-1280x720.jpg', '2020-12-17 13:55:59', 'superadminmmj01');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (11, 11, 4, NULL, '', '1fdzHnfdSqlHDjd1ouYGrroLqUlE9B1zq', '1SaJuOSZp9Y_YUrmxRKPvq8H2_-OUjVuC', 'https://drive.google.com/file/d/1fdzHnfdSqlHDjd1ouYGrroLqUlE9B1zq/view?usp=drivesdk', 'assets/file_arsip/391259.jpg', '391259.jpg', '2020-12-17 13:56:02', 'superadminmmj01');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (12, 12, 3, NULL, '', '1RFupvdG_NNuRVHqkY2UWwtjDJuhuiJov', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1RFupvdG_NNuRVHqkY2UWwtjDJuhuiJov/view?usp=drivesdk', 'assets/file_arsip/04._SK._EKO_PUNOMO.pdf', '04._SK._EKO_PUNOMO.pdf', '2020-12-17 14:22:49', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (13, 13, 3, NULL, '', '1X8eHhZ5KHhcCUsqUCIa0EcJ2rHaTaylL', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1X8eHhZ5KHhcCUsqUCIa0EcJ2rHaTaylL/view?usp=drivesdk', 'assets/file_arsip/05._SK_FAISAL_ABDUL_HARIS.pdf', '05._SK_FAISAL_ABDUL_HARIS.pdf', '2020-12-17 14:28:53', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (14, 14, 3, NULL, '', '1ji1TU604KjAYUOvj30MHpc_VDnx-uEQO', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1ji1TU604KjAYUOvj30MHpc_VDnx-uEQO/view?usp=drivesdk', 'assets/file_arsip/06._SK._KHOIRIDIN.pdf', '06._SK._KHOIRIDIN.pdf', '2020-12-17 14:41:33', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (15, 15, 3, NULL, '', '1XjdqDNIOZaB-zoEKXEPkJSU8iFKMl2rE', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1XjdqDNIOZaB-zoEKXEPkJSU8iFKMl2rE/view?usp=drivesdk', 'assets/file_arsip/07._SK._RUSWANTO.pdf', '07._SK._RUSWANTO.pdf', '2020-12-17 14:47:11', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (16, 16, 3, NULL, '', '1jGAzdoDnsnUofszy56QAR6-_RBTE4C1H', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1jGAzdoDnsnUofszy56QAR6-_RBTE4C1H/view?usp=drivesdk', 'assets/file_arsip/08._SK._M._RIDWAN.pdf', '08._SK._M._RIDWAN.pdf', '2020-12-17 14:51:28', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (17, 17, 3, NULL, '', '1oz6LPl-ZIyUaN9M7pd4jRLTcpg3pe0J4', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1oz6LPl-ZIyUaN9M7pd4jRLTcpg3pe0J4/view?usp=drivesdk', 'assets/file_arsip/09._SK_IDA_WIDIAHASTUTI.pdf', '09._SK_IDA_WIDIAHASTUTI.pdf', '2020-12-17 14:55:00', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (18, 18, 3, NULL, '', '1OtpbTF1LgsLh6y4AK533bwjo4A9knzvV', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1OtpbTF1LgsLh6y4AK533bwjo4A9knzvV/view?usp=drivesdk', 'assets/file_arsip/10._SK._KARTIKO_A._WIBOWO.pdf', '10._SK._KARTIKO_A._WIBOWO.pdf', '2020-12-17 21:53:26', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (19, 19, 3, NULL, '', '1nDS2qSAhszoqhbvHV1uVb3rFmIwK-Ysj', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1nDS2qSAhszoqhbvHV1uVb3rFmIwK-Ysj/view?usp=drivesdk', 'assets/file_arsip/11._SK._SAAT_SUHARTO_AMJAD.pdf', '11._SK._SAAT_SUHARTO_AMJAD.pdf', '2020-12-17 21:57:21', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (20, 20, 3, NULL, '', '1IPXnerhvwFud4DoFIs3NzJp2DQqqdsTK', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1IPXnerhvwFud4DoFIs3NzJp2DQqqdsTK/view?usp=drivesdk', 'assets/file_arsip/12._SK._KHOIR_KUSNANDAR.pdf', '12._SK._KHOIR_KUSNANDAR.pdf', '2020-12-17 22:00:58', 'adminpbmt');
INSERT INTO `arsip_files` (`id`, `arsip_id`, `tokens_id`, `email`, `code`, `gdrive_file_id`, `gdrive_folder_id`, `gdrive_file_url`, `file_location`, `file_name`, `created_at`, `created_by`) VALUES (21, 21, 3, NULL, '', '1QSDl-_D7abxXN1yIoUQiwJZI4EzdQNzl', '1dajtkU1_Fx1BgdboVijsREiJdE8jOWJ3', 'https://drive.google.com/file/d/1QSDl-_D7abxXN1yIoUQiwJZI4EzdQNzl/view?usp=drivesdk', 'assets/file_arsip/13._SK._ASEP_SUTISNA.docx.pdf', '13._SK._ASEP_SUTISNA.docx.pdf', '2020-12-17 22:03:28', 'adminpbmt');


#
# TABLE STRUCTURE FOR: arsip_jenis
#

DROP TABLE IF EXISTS `arsip_jenis`;

CREATE TABLE `arsip_jenis` (
  `id_arsip_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `arsip_id` int(11) NOT NULL,
  `jenis_arsip_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_arsip_jenis`),
  KEY `FK_arsip_jenis_arsip` (`arsip_id`),
  KEY `FK_arsip_jenis_jenis_arsip` (`jenis_arsip_id`),
  CONSTRAINT `FK_arsip_jenis_arsip` FOREIGN KEY (`arsip_id`) REFERENCES `arsip` (`id_arsip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_arsip_jenis_jenis_arsip` FOREIGN KEY (`jenis_arsip_id`) REFERENCES `jenis_arsip` (`id_jenis`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (2, 2, 3, '2020-12-17 07:49:27');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (3, 3, 4, '2020-12-17 08:44:29');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (8, 7, 5, '2020-12-17 13:41:25');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (9, 6, 4, '2020-12-17 13:43:58');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (13, 10, 3, '2020-12-17 13:55:11');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (14, 11, 3, '2020-12-17 13:56:02');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (15, 12, 4, '2020-12-17 14:22:49');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (16, 9, 4, '2020-12-17 14:23:38');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (17, 8, 4, '2020-12-17 14:24:32');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (18, 13, 4, '2020-12-17 14:28:53');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (19, 14, 4, '2020-12-17 14:41:33');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (20, 15, 4, '2020-12-17 14:47:12');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (21, 16, 4, '2020-12-17 14:51:29');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (23, 17, 4, '2020-12-17 14:55:41');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (24, 18, 4, '2020-12-17 21:53:27');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (25, 19, 4, '2020-12-17 21:57:22');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (26, 20, 4, '2020-12-17 22:00:59');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (27, 21, 4, '2020-12-17 22:03:29');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (29, 23, 3, '2020-12-25 08:16:15');
INSERT INTO `arsip_jenis` (`id_arsip_jenis`, `arsip_id`, `jenis_arsip_id`, `created_at`) VALUES (30, 24, 3, '2020-12-25 08:24:12');


#
# TABLE STRUCTURE FOR: baris
#

DROP TABLE IF EXISTS `baris`;

CREATE TABLE `baris` (
  `id_baris` int(11) NOT NULL AUTO_INCREMENT,
  `baris_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_baris` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_baris`),
  KEY `FK_baris_instansi` (`instansi_id`),
  KEY `FK_baris_cabang` (`cabang_id`),
  CONSTRAINT `FK_baris_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_baris_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `baris` (`id_baris`, `baris_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_baris`, `deleted_by`, `deleted_at`) VALUES (1, '1', 1, 1, '2020-12-17 07:50:31', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `baris` (`id_baris`, `baris_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_baris`, `deleted_by`, `deleted_at`) VALUES (2, '1', 2, 2, '2020-12-17 07:34:12', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `baris` (`id_baris`, `baris_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_baris`, `deleted_by`, `deleted_at`) VALUES (3, '2', 4, 5, '2020-12-17 13:34:59', 'superadminmmj01', '', NULL, 0, NULL, NULL);
INSERT INTO `baris` (`id_baris`, `baris_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_baris`, `deleted_by`, `deleted_at`) VALUES (4, '1', 2, 4, '2020-12-25 07:55:21', 'adminmaal', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: box
#

DROP TABLE IF EXISTS `box`;

CREATE TABLE `box` (
  `id_box` int(11) NOT NULL AUTO_INCREMENT,
  `box_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_box` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_box`),
  KEY `FK_box_instansi` (`instansi_id`),
  KEY `FK_box_cabang` (`cabang_id`),
  CONSTRAINT `FK_box_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_box_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `box` (`id_box`, `box_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_box`, `deleted_by`, `deleted_at`) VALUES (1, '1', 1, 1, '2020-12-17 07:50:36', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `box` (`id_box`, `box_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_box`, `deleted_by`, `deleted_at`) VALUES (2, '1', 2, 2, '2020-12-17 07:34:20', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `box` (`id_box`, `box_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_box`, `deleted_by`, `deleted_at`) VALUES (3, '1', 4, 5, '2020-12-17 13:35:02', 'superadminmmj01', '', NULL, 0, NULL, NULL);
INSERT INTO `box` (`id_box`, `box_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_box`, `deleted_by`, `deleted_at`) VALUES (4, '1', 2, 4, '2020-12-25 07:55:28', 'adminmaal', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: cabang
#

DROP TABLE IF EXISTS `cabang`;

CREATE TABLE `cabang` (
  `id_cabang` int(11) NOT NULL AUTO_INCREMENT,
  `cabang_name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instansi_id` int(11) DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_cabang` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_cabang`),
  KEY `cabang_FK` (`instansi_id`),
  CONSTRAINT `cabang_FK` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (1, 'Pusat', 1, 'muhazmi', '2020-12-17 06:53:18', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (2, 'MPP', 2, 'jondhy', '2020-12-17 07:20:49', 'jondhy', '2020-12-17 13:04:44', 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (4, 'PBMT MAAL', 2, 'eduarsip', '2020-12-17 12:06:48', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (5, 'MMJ 01', 4, 'muhazmi', '2020-12-17 12:50:36', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (6, 'MMJ 02', 4, 'muhazmi', '2020-12-17 12:50:43', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (7, 'PBMT AKREDITASI', 2, 'jondhy', '2020-12-17 22:33:41', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (8, 'PBMT ROWASIA', 2, 'jondhy', '2020-12-17 22:34:07', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (9, 'PBMT TAAWUN', 2, 'jondhy', '2020-12-17 22:34:27', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (10, 'PBMT VENTURA', 2, 'jondhy', '2020-12-17 22:34:41', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (11, 'PBMT TRAVEL', 2, 'jondhy', '2020-12-17 22:34:55', '', NULL, 0, NULL, NULL);
INSERT INTO `cabang` (`id_cabang`, `cabang_name`, `instansi_id`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete_cabang`, `deleted_by`, `deleted_at`) VALUES (12, 'PBMT INSTITUTE', 2, 'jondhy', '2020-12-17 22:35:41', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: company
#

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `id_company` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_desc` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_address` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_maps` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_phone` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_phone2` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_fax` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_gmail` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_photo` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_photo_thumb` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_company`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `company` (`id_company`, `company_name`, `company_desc`, `company_address`, `company_maps`, `company_phone`, `company_phone2`, `company_fax`, `company_email`, `company_gmail`, `company_photo`, `company_photo_thumb`, `created_by`, `created_at`, `modified_by`, `modified_at`) VALUES (1, 'JonArsip', '<p>JonArsip adalah lembaga yang bergerak dibidang pnegelolaan arsip dan perpusatakaan</p>', 'Jl. Ringroad bARAT No 99 A dusun NUsupan Trihanggo Gamping Sleman Yogykarta', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63248.79889074844!2d110.31197864161997!3d-7.7845311706327145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a58865904a943%3A0xa0c11184a57f1f85!2sGraha%20PBMT%20Perhimpunan%20BMT%20Indonesia!5e0!3m2!1sen!2sid!4v1595374788862!5m2!1sen!2sid\" width=\"600\" height=\"450\" frameborder=\"0\" style=\"border:0;\" allowfullscreen=\"\" aria-hidden=\"false\" tabindex=\"0\"></iframe>\r\n', '081262215939', '0711412402', '24141', 'info@jonarsip.com', 'info@jonarsip.com', 'jonarsip20201217085908.jpg', 'jonarsip20201217085908_thumb.jpg', '', '2017-11-09 06:45:34', 'jondhy', '2020-12-17 01:59:08');


#
# TABLE STRUCTURE FOR: data_access
#

DROP TABLE IF EXISTS `data_access`;

CREATE TABLE `data_access` (
  `id_data_access` int(11) NOT NULL AUTO_INCREMENT,
  `data_access_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_data_access`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `data_access` (`id_data_access`, `data_access_name`, `color`) VALUES (1, 'Read', 'primary');
INSERT INTO `data_access` (`id_data_access`, `data_access_name`, `color`) VALUES (2, 'Create', 'info');
INSERT INTO `data_access` (`id_data_access`, `data_access_name`, `color`) VALUES (3, 'Update', 'warning');
INSERT INTO `data_access` (`id_data_access`, `data_access_name`, `color`) VALUES (4, 'Delete', 'danger');
INSERT INTO `data_access` (`id_data_access`, `data_access_name`, `color`) VALUES (5, 'Restore', 'success');


#
# TABLE STRUCTURE FOR: divisi
#

DROP TABLE IF EXISTS `divisi`;

CREATE TABLE `divisi` (
  `id_divisi` int(11) NOT NULL AUTO_INCREMENT,
  `divisi_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `divisi_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_divisi` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_divisi`),
  KEY `FK_divisi_instansi` (`instansi_id`),
  KEY `FK_divisi_cabang` (`cabang_id`),
  CONSTRAINT `FK_divisi_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_divisi_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (1, 'Umum', 'umum', 1, 1, '2020-12-17 06:53:27', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (2, 'SEKRETARIS EKSEKUTIF', 'sekretaris-eksekutif', 2, 2, '2020-12-17 07:21:30', 'jondhy', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (4, 'ADMIN MAAL', 'admin-maal', 2, 4, '2020-12-17 12:08:54', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (5, 'MMJ 01- UMUM', 'mmj-01-umum', 4, 5, '2020-12-17 12:50:58', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (6, 'MMJ 01- SDM', 'mmj-01-sdm', 4, 5, '2020-12-17 12:51:05', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (7, 'MMJ 02- KEUANGAN', 'mmj-02-keuangan', 4, 6, '2020-12-17 12:51:14', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (8, 'LAZYKMU', 'lazykmu', 2, 4, '2020-12-17 13:09:10', 'adminmaal', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (9, 'CROWDFUNDING', 'crowdfunding', 2, 4, '2020-12-17 13:09:33', 'adminmaal', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (10, 'SERAFOOD', 'serafood', 2, 4, '2020-12-17 13:09:44', 'adminmaal', '', NULL, 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (11, 'GRAHA/WAKAF', 'grahawakaf', 2, 4, '2020-12-17 13:10:28', 'adminmaal', 'adminmaal', '2020-12-17 13:10:58', 0, NULL, NULL);
INSERT INTO `divisi` (`id_divisi`, `divisi_name`, `divisi_slug`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_divisi`, `deleted_by`, `deleted_at`) VALUES (12, 'AKSI KEMANUSIAAN', 'aksi-kemanusiaan', 2, 4, '2020-12-17 13:13:01', 'adminmaal', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: footer
#

DROP TABLE IF EXISTS `footer`;

CREATE TABLE `footer` (
  `id_footer` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_footer`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `footer` (`id_footer`, `content`) VALUES (1, 'Copyright © 2020JonArsip');


#
# TABLE STRUCTURE FOR: instansi
#

DROP TABLE IF EXISTS `instansi`;

CREATE TABLE `instansi` (
  `id_instansi` int(11) NOT NULL AUTO_INCREMENT,
  `instansi_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_address` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_img` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_img_thumb` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` int(11) DEFAULT NULL,
  `active_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_instansi` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_instansi`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `instansi` (`id_instansi`, `instansi_name`, `instansi_address`, `instansi_phone`, `instansi_img`, `instansi_img_thumb`, `is_active`, `active_date`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_instansi`, `deleted_by`, `deleted_at`) VALUES (1, 'GrandAdmin Corp', 'Jl. ABCD', '0814718247', 'grandadmin-corp20201217090035.jpg', 'grandadmin-corp20201217090035_thumb.jpg', 1, '2029-12-31', '2020-12-17 06:52:31', 'muhazmi', 'jondhy', '2020-12-17 02:00:35', 0, NULL, NULL);
INSERT INTO `instansi` (`id_instansi`, `instansi_name`, `instansi_address`, `instansi_phone`, `instansi_img`, `instansi_img_thumb`, `is_active`, `active_date`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_instansi`, `deleted_by`, `deleted_at`) VALUES (2, 'PERHIMPUNAN BMT INDONESIA', 'Graha PBMT Indonesia Jl. Ringroad Barat No 99A Dusun Nusapan Trihanggo Gamping Sleman Yogyakarta', '082142507511', 'perhimpunan-bmt-indonesia20201217140750.jpg', 'perhimpunan-bmt-indonesia20201217140750_thumb.jpg', 1, '2022-12-17', '2020-12-17 07:07:50', 'jondhy', '', NULL, 0, NULL, NULL);
INSERT INTO `instansi` (`id_instansi`, `instansi_name`, `instansi_address`, `instansi_phone`, `instansi_img`, `instansi_img_thumb`, `is_active`, `active_date`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_instansi`, `deleted_by`, `deleted_at`) VALUES (4, 'PT MAJU MUNDUR JAYA', 'Asldkjalsd', '08129184', 'pt-maju-mundur-jaya20201217195014.png', 'pt-maju-mundur-jaya20201217195014_thumb.png', 1, '2029-12-31', '2020-12-17 12:50:15', 'muhazmi', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: jenis_arsip
#

DROP TABLE IF EXISTS `jenis_arsip`;

CREATE TABLE `jenis_arsip` (
  `id_jenis` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenis_slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_jenis` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_jenis`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jenis_arsip` (`id_jenis`, `jenis_name`, `jenis_slug`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_jenis`, `deleted_by`, `deleted_at`) VALUES (1, 'Audio', 'audio', '2020-01-09 06:50:15', '', '', '2020-03-08 21:11:01', 0, NULL, NULL);
INSERT INTO `jenis_arsip` (`id_jenis`, `jenis_name`, `jenis_slug`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_jenis`, `deleted_by`, `deleted_at`) VALUES (2, 'Video', 'video', '2020-01-09 06:50:15', '', '', '2020-03-08 21:11:01', 0, NULL, NULL);
INSERT INTO `jenis_arsip` (`id_jenis`, `jenis_name`, `jenis_slug`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_jenis`, `deleted_by`, `deleted_at`) VALUES (3, 'Gambar', 'gambar', '2020-01-09 06:50:15', '', '', '2020-03-08 21:11:01', 0, NULL, NULL);
INSERT INTO `jenis_arsip` (`id_jenis`, `jenis_name`, `jenis_slug`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_jenis`, `deleted_by`, `deleted_at`) VALUES (4, 'Text (file)', 'text-file', '2020-01-09 06:50:15', '', '', '2020-03-08 21:11:01', 0, NULL, NULL);
INSERT INTO `jenis_arsip` (`id_jenis`, `jenis_name`, `jenis_slug`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_jenis`, `deleted_by`, `deleted_at`) VALUES (5, 'Multy', 'multy', '2020-03-28 13:03:48', '', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: log_queries
#

DROP TABLE IF EXISTS `log_queries`;

CREATE TABLE `log_queries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_agent` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=223 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (1, 'INSERT INTO `instansi` (`instansi_name`, `instansi_address`, `instansi_phone`, `active_date`, `is_active`, `instansi_img`, `instansi_img_thumb`, `created_by`) VALUES (\'PUSAT\', \'Jl. ABCD\', \'0814718247\', \'2029-12-31\', \'1\', \'pusat20201217065231.png\', \'pusat20201217065231_thumb.png\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 06:52:31', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (2, 'UPDATE `instansi` SET `instansi_name` = \'GrandAdmin Corp\', `instansi_address` = \'Jl. ABCD\', `instansi_phone` = \'0814718247\', `active_date` = \'2029-12-31\', `is_active` = \'1\', `modified_by` = \'muhazmi\'\nWHERE `id_instansi` = \'1\'', 'Muhammad Azmi', '2020-12-17 06:53:09', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (3, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'Pusat\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 06:53:18', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (4, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'1\', \'1\', \'Umum\', \'umum\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 06:53:27', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (5, 'UPDATE `users` SET `name` = \'Supriyadi\', `birthdate` = \'\', `birthplace` = \'\', `gender` = \'1\', `address` = \'\', `phone` = \'082111\', `email` = \'supriyadi.jondhy@gmail.com\', `username` = \'jondhy\', `instansi_id` = \'1\', `cabang_id` = \'1\', `divisi_id` = \'1\', `usertype_id` = \'5\', `modified_by` = \'muhazmi\'\nWHERE `id_users` = \'2\'', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (6, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'2\', \'1\')', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (7, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'2\', \'2\')', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (8, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'2\', \'3\')', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (9, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'2\', \'4\')', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (10, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'2\', \'5\')', 'Muhammad Azmi', '2020-12-17 06:59:17', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (11, 'UPDATE `users` SET `name` = \'Muhammad Azmi\', `birthdate` = \'\', `birthplace` = \'\', `gender` = \'1\', `address` = \'xx\', `phone` = \'081228289766\', `email` = \'azmi2793@gmail.com\', `username` = \'muhazmi\', `instansi_id` = \'1\', `cabang_id` = \'1\', `divisi_id` = \'1\', `usertype_id` = \'5\', `modified_by` = \'muhazmi\'\nWHERE `id_users` = \'1\'', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (12, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'1\', \'1\')', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (13, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'1\', \'2\')', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (14, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'1\', \'3\')', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (15, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'1\', \'4\')', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (16, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'1\', \'5\')', 'Muhammad Azmi', '2020-12-17 06:59:24', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (17, 'INSERT INTO `rak` (`rak_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:50:25', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (18, 'INSERT INTO `baris` (`baris_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:50:31', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (19, 'INSERT INTO `box` (`box_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:50:36', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (20, 'INSERT INTO `map` (`map_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:50:41', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (21, 'INSERT INTO `lokasi` (`lokasi_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'Lantai 1\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:50:49', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (22, 'UPDATE `tokens` SET `instansi_id` = \'1\', `folder_name` = \'GrandAdmin Corp LOCAL\', `modified_by` = \'muhazmi\'\nWHERE `id_tokens` = \'1\'', 'Muhammad Azmi', '2020-12-17 07:51:37', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (23, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'asd1\', \'askljask\', \'0\', \'2021-01-07\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:53:34', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (24, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (1, \'5\')', 'Muhammad Azmi', '2020-12-17 07:53:34', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (25, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'2\', \'ads2\', \'aklsc\', \'0\', \'2021-01-07\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:54:10', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (26, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (2, \'4\')', 'Muhammad Azmi', '2020-12-17 07:54:10', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (27, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'4\', \'dalskd4\', \'alscnalk\', \'0\', \'2020-12-31\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 07:59:59', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (28, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (3, \'3\')', 'Muhammad Azmi', '2020-12-17 07:59:59', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (29, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 08:00:am\'\nWHERE `id_arsip` = \'3\'', 'Muhammad Azmi', '2020-12-17 08:00:20', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (30, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 08:00:am\'\nWHERE `id_arsip` = \'2\'', 'Muhammad Azmi', '2020-12-17 08:00:22', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (31, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 08:00:am\'\nWHERE `id_arsip` = \'1\'', 'Muhammad Azmi', '2020-12-17 08:00:25', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (32, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'001\', \'1\', \'alcnaslk\', \'0\', \'2021-01-01\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 08:02:37', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (33, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (4, \'5\')', 'Muhammad Azmi', '2020-12-17 08:02:37', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (34, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'002\', \'2\', \'lacnk\', \'0\', \'2021-01-01\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 08:03:34', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (35, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (5, \'3\')', 'Muhammad Azmi', '2020-12-17 08:03:34', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (36, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'1\', \'003\', \'3\', \'lzCNwe9oc\', \'0\', \'2020-12-31\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 08:04:16', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (37, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (6, \'3\')', 'Muhammad Azmi', '2020-12-17 08:04:16', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (38, 'UPDATE `arsip` SET `instansi_id` = \'1\', `cabang_id` = \'1\', `divisi_id` = \'1\', `user_id` = \'1\', `lokasi_id` = \'1\', `rak_id` = \'1\', `box_id` = \'1\', `map_id` = \'1\', `baris_id` = \'1\', `no_arsip` = \'003\', `arsip_name` = \'3\', `deskripsi_arsip` = \'lzCNwe9oc\', `keterangan` = \'0\', `masa_retensi` = \'2020-12-31\', `email` = \'wakpedwakyeng@gmail.com\', `gdrive_last_folder_name_target` = \'GrandAdmin Corp LOCAL\', `status_file` = \'1\', `modified_by` = \'muhazmi\'\nWHERE `id_arsip` = \'6\'', 'Muhammad Azmi', '2020-12-17 08:05:05', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (39, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'6\', \'3\')', 'Muhammad Azmi', '2020-12-17 08:05:05', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (40, 'UPDATE `arsip` SET `instansi_id` = \'1\', `cabang_id` = \'1\', `divisi_id` = \'1\', `user_id` = \'1\', `lokasi_id` = \'1\', `rak_id` = \'1\', `box_id` = \'1\', `map_id` = \'1\', `baris_id` = \'1\', `no_arsip` = \'001\', `arsip_name` = \'1\', `deskripsi_arsip` = \'alcnaslk\', `keterangan` = \'0\', `masa_retensi` = \'2021-01-01\', `email` = \'wakpedwakyeng@gmail.com\', `gdrive_last_folder_name_target` = \'GrandAdmin Corp LOCAL\', `status_file` = \'1\', `modified_by` = \'muhazmi\'\nWHERE `id_arsip` = \'4\'', 'Muhammad Azmi', '2020-12-17 08:05:41', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (41, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'4\', \'5\')', 'Muhammad Azmi', '2020-12-17 08:05:41', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (42, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'2\', \'1\', \'1\', \'1\', \'1\', \'1\', \'004\', \'4\', \'ARsiapdnao\', \'0\', \'2021-01-09\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 08:06:29', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (43, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (7, \'5\')', 'Muhammad Azmi', '2020-12-17 08:06:29', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (44, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 08:06:am\'\nWHERE `id_arsip` = \'6\'', 'Muhammad Azmi', '2020-12-17 08:06:48', '::1', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.97 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (45, 'UPDATE `company` SET `company_name` = \'JonArsip\', `company_desc` = \'<p>JonArsip adalah lembaga yang bergerak dibidang pnegelolaan arsip dan perpusatakaan</p>\', `company_address` = \'Jl. Ringroad bARAT No 99 A dusun NUsupan Trihanggo Gamping Sleman Yogykarta\', `company_maps` = \'<iframe src=\\\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63248.79889074844!2d110.31197864161997!3d-7.7845311706327145!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a58865904a943%3A0xa0c11184a57f1f85!2sGraha%20PBMT%20Perhimpunan%20BMT%20Indonesia!5e0!3m2!1sen!2sid!4v1595374788862!5m2!1sen!2sid\\\" width=\\\"600\\\" height=\\\"450\\\" frameborder=\\\"0\\\" style=\\\"border:0;\\\" allowfullscreen=\\\"\\\" aria-hidden=\\\"false\\\" tabindex=\\\"0\\\"></iframe>\\r\\n\', `company_phone` = \'081262215939\', `company_phone2` = \'0711412402\', `company_fax` = \'24141\', `company_email` = \'info@jonarsip.com\', `company_gmail` = \'info@jonarsip.com\', `modified_by` = \'jondhy\', `company_photo` = \'jonarsip20201217085908.jpg\', `company_photo_thumb` = \'jonarsip20201217085908_thumb.jpg\'\nWHERE `id_company` = \'1\'', 'Supriyadi', '2020-12-17 01:59:08', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (46, 'UPDATE `users` SET `name` = \'Supriyadi\', `birthdate` = \'\', `birthplace` = \'\', `gender` = \'1\', `address` = \'\', `phone` = \'082111\', `email` = \'supriyadi.jondhy@gmail.com\', `username` = \'jondhy\', `modified_by` = \'jondhy\', `photo` = \'jondhy20201217085946.jpg\', `photo_thumb` = \'jondhy20201217085946_thumb.jpg\'\nWHERE `id_users` = \'2\'', 'Supriyadi', '2020-12-17 01:59:46', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (47, 'UPDATE `instansi` SET `instansi_name` = \'GrandAdmin Corp\', `instansi_address` = \'Jl. ABCD\', `instansi_phone` = \'0814718247\', `active_date` = \'2029-12-31\', `is_active` = \'1\', `instansi_img` = \'grandadmin-corp20201217090035.jpg\', `instansi_img_thumb` = \'grandadmin-corp20201217090035_thumb.jpg\', `modified_by` = \'jondhy\'\nWHERE `id_instansi` = \'1\'', 'Supriyadi', '2020-12-17 02:00:35', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (48, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'1\', \'1\', \'1\', \'2\', \'1\', \'1\', \'1\', \'1\', \'1\', \'234598\', \'ini ters oke\', \'semoga ini lancar terus ya\', \'1\', \'2020-12-24\', \'wakpedwakyeng@gmail.com\', \'GrandAdmin Corp LOCAL\', \'1\', \'1\', \'jondhy\')', 'Supriyadi', '2020-12-17 02:41:40', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (49, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (1, \'3\')', 'Supriyadi', '2020-12-17 02:41:40', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (50, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 09:43:am\'\nWHERE `id_arsip` = \'1\'', 'Supriyadi', '2020-12-17 02:43:09', '114.142.171.29', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (51, 'INSERT INTO `instansi` (`instansi_name`, `instansi_address`, `instansi_phone`, `active_date`, `is_active`, `instansi_img`, `instansi_img_thumb`, `created_by`) VALUES (\'PERHIMPUNAN BMT INDONESIA\', \'Graha PBMT Indonesia Jl. Ringroad Barat No 99A Dusun Nusapan Trihanggo Gamping Sleman Yogyakarta\', \'082142507511\', \'2022-12-17\', \'1\', \'perhimpunan-bmt-indonesia20201217140750.jpg\', \'perhimpunan-bmt-indonesia20201217140750_thumb.jpg\', \'jondhy\')', 'Supriyadi', '2020-12-17 07:07:50', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (52, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PUSAT\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 07:20:49', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (53, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'2\', \'SEKRETARIS EKSEKUTIF\', \'sekretaris-eksekutif\', \'jondhy\')', 'Supriyadi', '2020-12-17 07:21:30', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (54, 'UPDATE `tokens` SET `instansi_id` = \'2\', `folder_name` = \'ARSIP PBMT\', `modified_by` = \'jondhy\'\nWHERE `id_tokens` = \'3\'', 'Supriyadi', '2020-12-17 07:25:13', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (55, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`, `photo`, `photo_thumb`) VALUES (\'PBMT\', \'12/15/2005\', \'YOGYAKARTA\', \'1\', \'YOGYAKARTA\', \'\', \'arsippbmt@gmail.com\', \'adminpbmt\', \'$2y$10$zDags0AlHDniyK0R44XX3.Ybhnh1D5r.nbl3NpSD/LjWEkvyPNn7m\', \'2\', \'2\', \'2\', \'2\', \'jondhy\', \'114.142.171.43\', \'adminpbmt20201217142831.jpg\', \'adminpbmt20201217142831_thumb.jpg\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (56, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (3, \'1\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (57, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (3, \'2\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (58, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (3, \'3\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (59, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (3, \'4\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (60, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (3, \'5\')', 'Supriyadi', '2020-12-17 07:28:31', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (61, 'INSERT INTO `rak` (`rak_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'2\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:34:04', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (62, 'INSERT INTO `baris` (`baris_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'2\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:34:12', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (63, 'INSERT INTO `box` (`box_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'2\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:34:20', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (64, 'INSERT INTO `map` (`map_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'2\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:34:30', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (65, 'INSERT INTO `lokasi` (`lokasi_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'GRHA PBMT\', \'2\', \'2\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:35:04', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (66, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.1\', \'SURAT PENETAPAN WALI AMANAH PBMT PERIODE 2020-2025\', \'Surat penetapan wali amanah PBMT periode 2020-2025 # Munas ke 4 #  tahun 2020\', \'0\', \'2030-11-16\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 07:49:27', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (67, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (2, \'3\')', 'PBMT', '2020-12-17 07:49:27', '114.142.171.43', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (68, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.1\', \'SK  MURSIDA RAMBE\', \'Nomor : 01/A/KPTS/WA/XI/2020 #Surat keputusan penetapan sebagai ketua umum Perhimpunan BMT Indonesia periode 2020-2025 \', \'0\', \'2025-11-16\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 08:44:29', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (69, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (3, \'4\')', 'PBMT', '2020-12-17 08:44:29', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (70, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.2\', \'SK M.BURHAN NASRUDDIN LATIEF SEBAGAI SEKRETARIS I\', \'Nomor : 01.01/KPTS/A/KET-PBMTI/XII/2020 # Surat keputusan pengangkatan M.Burhan N.L sebagai  sektertasi 1 Perhimpunan BMT Indonesia Periode 2020-2025\', \'0\', \'2025-11-16\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 08:56:46', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (71, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (4, \'4\')', 'PBMT', '2020-12-17 08:56:46', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (72, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.3\', \'SK. DWI HASTUTI AMBAR WULANDARI\', \'Nomor: 01.02/KPTS/A/PBMTI/XII/2020 # Surat keputusan Dwi Sri Ambar sebagai sekretaris II Perhimpunan BMT Indonesia periode 2020-2025\\r\\n\', \'0\', \'2025-11-16\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 09:01:30', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (73, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (5, \'4\')', 'PBMT', '2020-12-17 09:01:30', '114.142.169.21', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (74, 'INSERT INTO `instansi` (`instansi_name`, `instansi_address`, `instansi_phone`, `active_date`, `is_active`, `instansi_img`, `instansi_img_thumb`, `created_by`) VALUES (\'PBMT MAAL\', \'YOGYAKARTA\', \'0895322714499\', \'2021-12-17\', \'1\', \'pbmt-maal20201217184622.jpg\', \'pbmt-maal20201217184622_thumb.jpg\', \'jondhy\')', 'Supriyadi', '2020-12-17 11:46:22', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (75, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'CABANG PUSAT\', \'3\', \'jondhy\')', 'Supriyadi', '2020-12-17 11:47:04', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (76, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'3\', \'3\', \'KESEKRETARIATAN\', \'kesekretariatan\', \'jondhy\')', 'Supriyadi', '2020-12-17 11:48:20', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (77, 'UPDATE `divisi` SET `is_delete_divisi` = \'1\', `deleted_by` = \'jondhy\', `deleted_at` = \'2020-12-17 18:50:pm\'\nWHERE `id_divisi` = \'3\'', 'Supriyadi', '2020-12-17 11:50:07', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (78, 'DELETE FROM `divisi`\nWHERE `id_divisi` = \'3\'', 'Supriyadi', '2020-12-17 11:50:19', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (79, 'UPDATE `cabang` SET `is_delete_cabang` = \'1\', `deleted_by` = \'jondhy\', `deleted_at` = \'2020-12-17 18:50:pm\'\nWHERE `id_cabang` = \'3\'', 'Supriyadi', '2020-12-17 11:50:41', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (80, 'DELETE FROM `cabang`\nWHERE `id_cabang` = \'3\'', 'Supriyadi', '2020-12-17 11:50:52', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (81, 'UPDATE `instansi` SET `is_delete_instansi` = \'1\', `deleted_by` = \'jondhy\', `deleted_at` = \'2020-12-17 18:51:pm\'\nWHERE `id_instansi` = \'3\'', 'Supriyadi', '2020-12-17 11:51:07', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (82, 'DELETE FROM `instansi`\nWHERE `id_instansi` = \'3\'', 'Supriyadi', '2020-12-17 11:51:25', '114.142.169.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (83, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`, `photo`, `photo_thumb`) VALUES (\'eduarsip\', \'12/29/1999\', \'Yogyakarta\', \'1\', \'Yogyakarta\', \'09876\', \'eduarsip21@gmail.com\', \'eduarsip\', \'$2y$10$xxfLJ3jYtan.VGkjS8D66eBi//izCKFLzL6ywUPP..FqATr6CtK9K\', \'2\', \'2\', \'2\', \'5\', \'jondhy\', \'114.142.168.0\', \'eduarsip20201217190150.png\', \'eduarsip20201217190150_thumb.png\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (84, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (4, \'1\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (85, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (4, \'2\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (86, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (4, \'3\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (87, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (4, \'4\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (88, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (4, \'5\')', 'Supriyadi', '2020-12-17 12:01:50', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (89, 'UPDATE `users` SET `name` = \'PBMT\', `birthdate` = \'12/15/2005\', `birthplace` = \'YOGYAKARTA\', `gender` = \'1\', `address` = \'YOGYAKARTA\', `phone` = \'\', `email` = \'arsippbmt@gmail.com\', `username` = \'adminpbmt\', `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `usertype_id` = \'1\', `modified_by` = \'jondhy\'\nWHERE `id_users` = \'3\'', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (90, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'3\', \'1\')', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (91, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'3\', \'2\')', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (92, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'3\', \'3\')', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (93, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'3\', \'4\')', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (94, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'3\', \'5\')', 'Supriyadi', '2020-12-17 12:02:40', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (95, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT MAAL\', \'2\', \'eduarsip\')', 'eduarsip', '2020-12-17 12:06:48', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (96, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'ADMIN MAAL\', \'admin-maal\', \'adminpbmt\')', 'PBMT', '2020-12-17 12:08:54', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (97, 'INSERT INTO `lokasi` (`lokasi_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'DIR 2\', \'2\', \'4\', \'adminpbmt\')', 'PBMT', '2020-12-17 12:09:29', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (98, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`, `photo`, `photo_thumb`) VALUES (\'admin\', \'12/22/1991\', \'Yogyakarta\', \'1\', \'Yogyakarta\', \'9808\', \'arsippbmtm@gmail.com\', \'adminmaal\', \'$2y$10$SMSYGMMuxrbn3PYGJ2lVK.hrkPLoOZtF7yEd72H52lumvHrqWJqm6\', \'2\', \'4\', \'4\', \'2\', \'adminpbmt\', \'114.142.168.0\', \'adminmaal20201217191509.jpg\', \'adminmaal20201217191509_thumb.jpg\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (99, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (5, \'1\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (100, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (5, \'2\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (101, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (5, \'3\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (102, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (5, \'4\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (103, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (5, \'5\')', 'PBMT', '2020-12-17 12:15:09', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (104, 'UPDATE `users` SET `name` = \'admin\', `birthdate` = \'12/22/1991\', `birthplace` = \'Yogyakarta\', `gender` = \'1\', `address` = \'Yogyakarta\', `phone` = \'9808\', `email` = \'arsippbmtm@gmail.com\', `username` = \'adminmaal\', `instansi_id` = \'2\', `cabang_id` = \'4\', `divisi_id` = \'4\', `usertype_id` = \'2\', `modified_by` = \'adminpbmt\'\nWHERE `id_users` = \'5\'', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (105, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'5\', \'1\')', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (106, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'5\', \'2\')', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (107, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'5\', \'3\')', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (108, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'5\', \'4\')', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (109, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (\'5\', \'5\')', 'PBMT', '2020-12-17 12:17:37', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (110, 'INSERT INTO `instansi` (`instansi_name`, `instansi_address`, `instansi_phone`, `active_date`, `is_active`, `instansi_img`, `instansi_img_thumb`, `created_by`) VALUES (\'PT MAJU MUNDUR JAYA\', \'Asldkjalsd\', \'08129184\', \'2029-12-31\', \'1\', \'pt-maju-mundur-jaya20201217195014.png\', \'pt-maju-mundur-jaya20201217195014_thumb.png\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:50:15', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (111, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'MMJ 01\', \'4\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:50:36', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (112, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'MMJ 02\', \'4\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:50:43', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (113, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'4\', \'5\', \'MMJ 01- UMUM\', \'mmj-01-umum\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:50:58', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (114, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'4\', \'5\', \'MMJ 01- SDM\', \'mmj-01-sdm\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:51:05', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (115, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'4\', \'6\', \'MMJ 02- KEUANGAN\', \'mmj-02-keuangan\', \'muhazmi\')', 'Muhammad Azmi', '2020-12-17 12:51:14', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (116, 'UPDATE `cabang` SET `cabang_name` = \'MPP\', `instansi_id` = \'2\', `modified_by` = \'jondhy\'\nWHERE `id_cabang` = \'2\'', 'Supriyadi', '2020-12-17 13:04:44', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (117, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'LAZYKMU\', \'lazykmu\', \'adminmaal\')', 'admin', '2020-12-17 13:09:10', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (118, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'CROWDFUNDING\', \'crowdfunding\', \'adminmaal\')', 'admin', '2020-12-17 13:09:33', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (119, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'SERAFOOD\', \'serafood\', \'adminmaal\')', 'admin', '2020-12-17 13:09:44', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (120, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`) VALUES (\'MasterAdmin MMJ 01\', \'\', \'\', \'1\', \'\', \'\', \'masteradminmmj01@gmail.com\', \'masteradminmmj01\', \'$2y$10$RDA5uIGBuLn4gvcBppwC/eU6KqLf9YMT4QzAbiW7kZ/6zk8k7q7tG\', \'4\', \'5\', \'5\', \'1\', \'muhazmi\', \'175.158.37.101\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (121, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (6, \'1\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (122, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (6, \'2\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (123, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (6, \'3\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (124, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (6, \'4\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (125, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (6, \'5\')', 'Muhammad Azmi', '2020-12-17 13:10:12', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (126, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'GRAHA\', \'graha\', \'adminmaal\')', 'admin', '2020-12-17 13:10:28', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (127, 'UPDATE `divisi` SET `instansi_id` = \'2\', `cabang_id` = \'4\', `divisi_name` = \'GRAHA/WAKAF\', `divisi_slug` = \'grahawakaf\', `modified_by` = \'adminmaal\'\nWHERE `id_divisi` = \'11\'', 'admin', '2020-12-17 13:10:58', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (128, 'INSERT INTO `divisi` (`instansi_id`, `cabang_id`, `divisi_name`, `divisi_slug`, `created_by`) VALUES (\'2\', \'4\', \'AKSI KEMANUSIAAN\', \'aksi-kemanusiaan\', \'adminmaal\')', 'admin', '2020-12-17 13:13:01', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (129, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 20:22:pm\'\nWHERE `id_arsip` = \'5\'', 'Supriyadi', '2020-12-17 13:22:42', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (130, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-17 20:23:pm\'\nWHERE `id_arsip` = \'4\'', 'Supriyadi', '2020-12-17 13:23:04', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (131, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'05.2.1\', \'SK M.BURHAN NASRUDDIN LATIEF\', \'Nomor : 01.01/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai sekretaris 1 pengurus MPP periode 2020-2025 \', \'0\', \'2025-12-11\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 13:31:39', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (132, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (6, \'4\')', 'PBMT', '2020-12-17 13:31:39', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (133, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.1\', `arsip_name` = \'SK M.BURHAN NASRUDDIN LATIEF\', `deskripsi_arsip` = \'Nomor : 01.01/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai sekretaris 1 pengurus MPP periode 2020-2025 \', `keterangan` = \'0\', `masa_retensi` = \'2025-12-11\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'1\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'6\'', 'PBMT', '2020-12-17 13:32:34', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (134, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'6\', \'4\')', 'PBMT', '2020-12-17 13:32:34', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (135, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`) VALUES (\'Administrator MMJ 01\', \'\', \'\', \'1\', \'\', \'\', \'administratormmj01@gmail.com\', \'administratormmj01\', \'$2y$10$c583yrU6LO3lVLrbQ9qmX.yvPQmtxCvklpMU6EnNunHd3DYVaz0CW\', \'4\', \'5\', \'5\', \'3\', \'masteradminmmj01\', \'175.158.37.101\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (136, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (7, \'1\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (137, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (7, \'2\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (138, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (7, \'3\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (139, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (7, \'4\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (140, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (7, \'5\')', 'MasterAdmin MMJ 01', '2020-12-17 13:32:52', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (141, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`) VALUES (\'Budi Anduk\', \'\', \'\', \'1\', \'\', \'\', \'budianduk@gmail.com\', \'budianduk\', \'$2y$10$.Jr1io7EDLbIpwh85wNWPO26nyygCCnnsMmyEObH4qiKJPXSXqgk6\', \'4\', \'5\', \'6\', \'4\', \'masteradminmmj01\', \'175.158.37.101\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (142, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (8, \'1\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (143, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (8, \'2\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (144, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (8, \'3\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (145, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (8, \'4\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (146, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (8, \'5\')', 'MasterAdmin MMJ 01', '2020-12-17 13:33:37', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (147, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`) VALUES (\'SuperAdmin MMJ 01\', \'\', \'\', \'1\', \'\', \'\', \'superadminmmj01@gmail.com\', \'superadminmmj01\', \'$2y$10$GoP/XyWwuz1l1plxmy7hDeU/ebjeMYK5QpWjvOEIMDLcGF/EinhVW\', \'4\', \'5\', \'6\', \'2\', \'masteradminmmj01\', \'175.158.37.101\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (148, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (9, \'1\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (149, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (9, \'2\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (150, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (9, \'3\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (151, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (9, \'4\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (152, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (9, \'5\')', 'MasterAdmin MMJ 01', '2020-12-17 13:34:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (153, 'INSERT INTO `rak` (`rak_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'4\', \'5\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:34:56', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (154, 'INSERT INTO `baris` (`baris_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'2\', \'4\', \'5\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:34:59', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (155, 'INSERT INTO `box` (`box_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'4\', \'5\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:35:02', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (156, 'INSERT INTO `map` (`map_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'3\', \'4\', \'5\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:35:05', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (157, 'INSERT INTO `lokasi` (`lokasi_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'Lt. 2\', \'4\', \'5\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:35:12', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (158, 'UPDATE `lokasi` SET `lokasi_name` = \'Lt. 1\', `instansi_id` = \'4\', `cabang_id` = \'5\', `modified_by` = \'superadminmmj01\'\nWHERE `id_lokasi` = \'4\'', 'SuperAdmin MMJ 01', '2020-12-17 13:35:17', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (159, 'UPDATE `tokens` SET `instansi_id` = \'4\', `folder_name` = \'MMJ\', `modified_by` = \'muhazmi\'\nWHERE `id_tokens` = \'4\'', 'Muhammad Azmi', '2020-12-17 13:38:11', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (160, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'4\', \'5\', \'5\', \'7\', \'4\', \'3\', \'3\', \'3\', \'3\', \'1928419\', \'lKANCqioadu\', \'lacnaiowdu\', \'0\', \'2020-12-31\', \'wakpedwakyeng@gmail.com\', \'MMJ\', \'1\', \'1\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:41:25', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (161, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (7, \'5\')', 'SuperAdmin MMJ 01', '2020-12-17 13:41:25', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (162, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.2\', `arsip_name` = \'SK M.BURHAN NASRUDDIN LATIEF\', `deskripsi_arsip` = \'Nomor : 01.01/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai sekretaris 1 pengurus MPP periode 2020-2025 \', `keterangan` = \'0\', `masa_retensi` = \'2025-12-11\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'1\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'6\'', 'PBMT', '2020-12-17 13:43:58', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (163, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'6\', \'4\')', 'PBMT', '2020-12-17 13:43:58', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (164, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.3\', \'SK. DWI HASTUTI AMBAR WULANDARI\', \'Nomor : 01.02/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai sekretaris 2 pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 13:48:33', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (165, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (8, \'4\')', 'PBMT', '2020-12-17 13:48:33', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (166, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.4\', \'SK BUDI SANTOSO\', \'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai bendahara 1 pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 13:51:22', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (167, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (9, \'4\')', 'PBMT', '2020-12-17 13:51:22', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (168, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.4\', `arsip_name` = \'SK BUDI SANTOSO\', `deskripsi_arsip` = \'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK M. Burhan Nasruddin Latief sebagai bendahara 1 pengurus MPP periode 2020-2025\', `keterangan` = \'0\', `masa_retensi` = \'2025-12-10\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'0\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'9\'', 'PBMT', '2020-12-17 13:51:56', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (169, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'9\', \'4\')', 'PBMT', '2020-12-17 13:51:56', '114.142.168.0', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (170, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'4\', \'5\', \'5\', \'7\', \'4\', \'3\', \'3\', \'3\', \'3\', \'12401894\', \'JAscjklBQicu\', \'aklsjcbnai\', \'0\', \'2020-12-30\', \'wakpedwakyeng@gmail.com\', \'MMJ\', \'1\', \'1\', \'administratormmj01\')', 'Administrator MMJ 01', '2020-12-17 13:55:11', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (171, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (10, \'3\')', 'Administrator MMJ 01', '2020-12-17 13:55:11', '175.158.37.101', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (172, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'4\', \'5\', \'6\', \'9\', \'4\', \'3\', \'3\', \'3\', \'3\', \'1250917490\', \'kasncao\', \'aALSCKo\', \'0\', \'2020-12-31\', \'wakpedwakyeng@gmail.com\', \'MMJ\', \'1\', \'1\', \'superadminmmj01\')', 'SuperAdmin MMJ 01', '2020-12-17 13:56:02', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (173, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (11, \'3\')', 'SuperAdmin MMJ 01', '2020-12-17 13:56:02', '175.158.37.101', 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (174, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.5\', \'SK EKO PURNOMO\', \'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK Eko Purnomo sebagai bendahara 2 pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:22:49', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (175, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (12, \'4\')', 'PBMT', '2020-12-17 14:22:49', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (176, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.4\', `arsip_name` = \'SK BUDI SANTOSO\', `deskripsi_arsip` = \'Nomor : 01.03/KPTS/A/PBMT/XII/2020 # SK Budi Santoso sebagai bendahara 1 pengurus MPP periode 2020-2025\', `keterangan` = \'0\', `masa_retensi` = \'2025-12-10\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'0\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'9\'', 'PBMT', '2020-12-17 14:23:38', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (177, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'9\', \'4\')', 'PBMT', '2020-12-17 14:23:38', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (178, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.3\', `arsip_name` = \'SK. DWI HASTUTI AMBAR WULANDARI\', `deskripsi_arsip` = \'Nomor : 01.02/KPTS/A/PBMT/XII/2020 # SK Dwi Hastuti Ambar Wulandari (ririn) sebagai sekretaris 2 pengurus MPP periode 2020-2025\', `keterangan` = \'0\', `masa_retensi` = \'2025-12-10\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'0\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'8\'', 'PBMT', '2020-12-17 14:24:32', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (179, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'8\', \'4\')', 'PBMT', '2020-12-17 14:24:32', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (180, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.6\', \'SK FAISAL ABDUL HARIS\', \'Nomor : 01.05/KPTS/A/PBMT/XII/2020 # SK Faisal Abdul Haris sebagai ketua bidang internal pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:28:53', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (181, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (13, \'4\')', 'PBMT', '2020-12-17 14:28:53', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (182, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.7\', \'SK KHOIRIDIN\', \'Nomor : 01.06/KPTS/A/PBMT/XII/2020 # SK Khoiridin sebagai ketua bidang eksternal pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:41:33', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (183, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (14, \'4\')', 'PBMT', '2020-12-17 14:41:33', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (184, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.8\', \'SK RUSWANTO\', \'Nomor : 01.07/KPTS/A/PBMT/XII/2020 # SK Ruswanto sebagai ketua bidang kepatuhan dan akreditasi pengurus MPP periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:47:12', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (185, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (15, \'4\')', 'PBMT', '2020-12-17 14:47:12', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (186, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.9\', \'SK M.RIDWAN\', \'Nomor : 01.08/KPTS/A/PBMT/XII/2020 # SK M. Riwan sebagai Direktur PBMT Maal periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:51:29', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (187, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (16, \'4\')', 'PBMT', '2020-12-17 14:51:29', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (188, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.10\', \'SK IDA WIDIAHASTUTI\', \'Nomor : 01.08/KPTS/A/PBMT/XII/2020 # SK Ida Widiahastuti sebagai Direktur PBMT Taawun periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 14:55:00', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (189, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (17, \'4\')', 'PBMT', '2020-12-17 14:55:00', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (190, 'UPDATE `arsip` SET `instansi_id` = \'2\', `cabang_id` = \'2\', `divisi_id` = \'2\', `user_id` = \'3\', `lokasi_id` = \'2\', `rak_id` = \'2\', `box_id` = \'2\', `map_id` = \'2\', `baris_id` = \'2\', `no_arsip` = \'005.2.10\', `arsip_name` = \'SK IDA WIDIAHASTUTI\', `deskripsi_arsip` = \'Nomor : 01.09/KPTS/A/PBMT/XII/2020 # SK Ida Widiahastuti sebagai Direktur PBMT Taawun periode 2020-2025\', `keterangan` = \'0\', `masa_retensi` = \'2025-12-10\', `email` = \'arsippbmt@gmail.com\', `gdrive_last_folder_name_target` = \'ARSIP PBMT\', `status_file` = \'0\', `modified_by` = \'adminpbmt\'\nWHERE `id_arsip` = \'17\'', 'PBMT', '2020-12-17 14:55:41', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (191, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (\'17\', \'4\')', 'PBMT', '2020-12-17 14:55:41', '114.142.171.40', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (192, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.11\', \'SK KARTIKO ADI WIBOWO\', \'Nomor : 01.10/KPTS/A/PBMT/XII/2020 # SK Kartiko Adi Wibowo sebagai Direktur PBMT Institute periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 21:53:27', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (193, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (18, \'4\')', 'PBMT', '2020-12-17 21:53:27', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (194, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.12\', \'SK SAAT SUHARTO AMJAD\', \'Nomor : 01.11/KPTS/A/PBMT/XII/2020 # SK Saat Suharto Amjad sebagai Komisaris Utama PBMT Ventura periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 21:57:22', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (195, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (19, \'4\')', 'PBMT', '2020-12-17 21:57:22', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (196, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.13\', \'SK KHOIR KUSNANDAR\', \'Nomor : 01.12/KPTS/A/PBMT/XII/2020 # SK Khoir Kusnandar sebagai Direktur PBMT Rowasia periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 22:00:59', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (197, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (20, \'4\')', 'PBMT', '2020-12-17 22:00:59', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (198, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'2\', \'2\', \'3\', \'2\', \'2\', \'2\', \'2\', \'2\', \'005.2.14\', \'SK ASEP SUTISNA\', \'Nomor : 01.13/KPTS/A/PBMT/XII/2020 # SK Asep Sutisna sebagai Direktur PBMT Travel periode 2020-2025\', \'0\', \'2025-12-10\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'0\', \'1\', \'adminpbmt\')', 'PBMT', '2020-12-17 22:03:29', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (199, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (21, \'4\')', 'PBMT', '2020-12-17 22:03:29', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (200, 'INSERT INTO `users` (`name`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `instansi_id`, `cabang_id`, `divisi_id`, `usertype_id`, `created_by`, `ip_add_reg`, `photo`, `photo_thumb`) VALUES (\'rosi\', \'12/22/2020\', \'Yogyakarta\', \'1\', \'Yogyakarta\', \'12342\', \'rosimaal@gmail.com\', \'rosimaal\', \'$2y$10$CwtgrrOnm7pJyr8pZ52oreshcGj7y9i228gFajmxx//45xUXEJA8m\', \'2\', \'4\', \'4\', \'3\', \'adminmaal\', \'114.142.171.22\', \'rosimaal20201218052747.png\', \'rosimaal20201218052747_thumb.png\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (201, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (10, \'1\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (202, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (10, \'2\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (203, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (10, \'3\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (204, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (10, \'4\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (205, 'INSERT INTO `users_data_access` (`user_id`, `data_access_id`) VALUES (10, \'5\')', 'admin', '2020-12-17 22:27:47', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (206, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT AKREDITASI\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:33:41', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (207, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT ROWASIA\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:34:07', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (208, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT TAAWUN\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:34:27', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (209, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT VENTURA\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:34:41', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (210, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT TRAVEL\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:34:55', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (211, 'INSERT INTO `cabang` (`cabang_name`, `instansi_id`, `created_by`) VALUES (\'PBMT INSTITUTE\', \'2\', \'jondhy\')', 'Supriyadi', '2020-12-17 22:35:41', '114.142.171.22', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (212, 'INSERT INTO `rak` (`rak_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'4\', \'adminmaal\')', 'admin', '2020-12-25 07:55:15', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (213, 'INSERT INTO `baris` (`baris_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'4\', \'adminmaal\')', 'admin', '2020-12-25 07:55:21', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (214, 'INSERT INTO `box` (`box_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'4\', \'adminmaal\')', 'admin', '2020-12-25 07:55:28', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (215, 'INSERT INTO `map` (`map_name`, `instansi_id`, `cabang_id`, `created_by`) VALUES (\'1\', \'2\', \'4\', \'adminmaal\')', 'admin', '2020-12-25 07:55:36', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (216, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'4\', \'4\', \'10\', \'3\', \'4\', \'4\', \'4\', \'4\', \'0945\', \'tes besar\', \'adfadfafa\', \'1\', \'2020-12-31\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminmaal\')', 'admin', '2020-12-25 08:02:01', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (217, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (22, \'3\')', 'admin', '2020-12-25 08:02:01', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (218, 'UPDATE `arsip` SET `is_delete` = \'1\', `deleted_by` = NULL, `deleted_at` = \'2020-12-25 15:05:pm\'\nWHERE `id_arsip` = \'22\'', 'admin', '2020-12-25 08:05:43', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (219, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'4\', \'4\', \'10\', \'3\', \'4\', \'4\', \'4\', \'4\', \'43567\', \'tes besar\', \'ya tes vps \', \'1\', \'2020-12-31\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'adminmaal\')', 'admin', '2020-12-25 08:16:15', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (220, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (23, \'3\')', 'admin', '2020-12-25 08:16:15', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (221, 'INSERT INTO `arsip` (`instansi_id`, `cabang_id`, `divisi_id`, `user_id`, `lokasi_id`, `rak_id`, `box_id`, `map_id`, `baris_id`, `no_arsip`, `arsip_name`, `deskripsi_arsip`, `keterangan`, `masa_retensi`, `email`, `gdrive_last_folder_name_target`, `status_file`, `is_available`, `created_by`) VALUES (\'2\', \'4\', \'4\', \'5\', \'3\', \'4\', \'4\', \'4\', \'4\', \'233\', \'asip tes\', \'ytre\', \'1\', \'2020-12-25\', \'arsippbmt@gmail.com\', \'ARSIP PBMT\', \'1\', \'1\', \'jondhy\')', 'Supriyadi', '2020-12-25 08:24:12', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');
INSERT INTO `log_queries` (`id`, `content`, `created_by`, `created_at`, `ip_address`, `user_agent`) VALUES (222, 'INSERT INTO `arsip_jenis` (`arsip_id`, `jenis_arsip_id`) VALUES (24, \'3\')', 'Supriyadi', '2020-12-25 08:24:12', '114.142.169.49', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: lokasi
#

DROP TABLE IF EXISTS `lokasi`;

CREATE TABLE `lokasi` (
  `id_lokasi` int(11) NOT NULL AUTO_INCREMENT,
  `lokasi_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_lokasi` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_lokasi`),
  KEY `FK_lokasi_instansi` (`instansi_id`),
  KEY `FK_lokasi_cabang` (`cabang_id`),
  CONSTRAINT `FK_lokasi_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_lokasi_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `lokasi` (`id_lokasi`, `lokasi_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_lokasi`, `deleted_by`, `deleted_at`) VALUES (1, 'Lantai 1', 1, 1, '2020-12-17 07:50:49', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `lokasi` (`id_lokasi`, `lokasi_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_lokasi`, `deleted_by`, `deleted_at`) VALUES (2, 'GRHA PBMT', 2, 2, '2020-12-17 07:35:04', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `lokasi` (`id_lokasi`, `lokasi_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_lokasi`, `deleted_by`, `deleted_at`) VALUES (3, 'DIR 2', 2, 4, '2020-12-17 12:09:29', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `lokasi` (`id_lokasi`, `lokasi_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_lokasi`, `deleted_by`, `deleted_at`) VALUES (4, 'Lt. 1', 4, 5, '2020-12-17 13:35:12', 'superadminmmj01', 'superadminmmj01', '2020-12-17 13:35:17', 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: map
#

DROP TABLE IF EXISTS `map`;

CREATE TABLE `map` (
  `id_map` int(11) NOT NULL AUTO_INCREMENT,
  `map_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_map` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_map`),
  KEY `FK_map_instansi` (`instansi_id`),
  KEY `FK_map_cabang` (`cabang_id`),
  CONSTRAINT `FK_map_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_map_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `map` (`id_map`, `map_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_map`, `deleted_by`, `deleted_at`) VALUES (1, '1', 1, 1, '2020-12-17 07:50:41', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `map` (`id_map`, `map_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_map`, `deleted_by`, `deleted_at`) VALUES (2, '1', 2, 2, '2020-12-17 07:34:30', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `map` (`id_map`, `map_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_map`, `deleted_by`, `deleted_at`) VALUES (3, '3', 4, 5, '2020-12-17 13:35:05', 'superadminmmj01', '', NULL, 0, NULL, NULL);
INSERT INTO `map` (`id_map`, `map_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_map`, `deleted_by`, `deleted_at`) VALUES (4, '1', 2, 4, '2020-12-25 07:55:36', 'adminmaal', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: menu
#

DROP TABLE IF EXISTS `menu`;

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL AUTO_INCREMENT,
  `menu_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_controller` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_function` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `order_no` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_menu`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (5, 'PEMINJAMAN', 'peminjaman', '#', 'fa-edit', 1, 1);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (6, 'PENGEMBALIAN', 'pengembalian', '#', 'fa-edit', 1, 2);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (7, 'ARSIP', 'arsip', '#', 'fa-archive', 1, 3);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (8, 'RAK', 'rak', '#', 'fa-building', 1, 4);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (9, 'BARIS', 'baris', '#', 'fa-bookmark', 1, 5);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (10, 'LAPORAN', 'laporan', '#', 'fa-file', 1, 8);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (11, 'BOX', 'box', '#', 'fa-inbox', 1, 6);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (12, 'MAP', 'map', '#', 'fa-book', 1, 7);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (13, 'DIVISI', 'divisi', '#', 'fa-map-signs', 1, 12);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (14, 'INSTANSI', 'instansi', '#', 'fa-arrows', 1, 10);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (15, 'LOKASI ARSIP', 'lokasi', '#', 'fa-map-pin', 1, 9);
INSERT INTO `menu` (`id_menu`, `menu_name`, `menu_controller`, `menu_function`, `menu_icon`, `is_active`, `order_no`) VALUES (16, 'CABANG', 'cabang', '#', 'fa-map-signs', 1, 11);


#
# TABLE STRUCTURE FOR: menu_access
#

DROP TABLE IF EXISTS `menu_access`;

CREATE TABLE `menu_access` (
  `id_menu_access` int(11) NOT NULL AUTO_INCREMENT,
  `usertype_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_menu_access`),
  KEY `FK_menu_access_usertype` (`usertype_id`),
  KEY `FK_menu_access_menu` (`menu_id`),
  KEY `FK_menu_access_submenu` (`submenu_id`),
  CONSTRAINT `FK_menu_access_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_menu_access_submenu` FOREIGN KEY (`submenu_id`) REFERENCES `submenu` (`id_submenu`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_menu_access_usertype` FOREIGN KEY (`usertype_id`) REFERENCES `usertype` (`id_usertype`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (1, 1, 5, 7);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (2, 1, 5, 9);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (4, 1, 10, 18);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (5, 1, 10, 19);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (6, 1, 7, 13);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (7, 1, 7, 12);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (8, 1, 9, 17);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (9, 1, 9, 16);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (10, 1, 8, 15);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (11, 1, 8, 14);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (12, 1, 6, 11);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (13, 1, 6, 10);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (18, 1, 7, 20);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (19, 1, 5, 21);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (20, 1, 6, 22);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (21, 1, 9, 23);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (22, 1, 8, 24);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (26, 2, 7, 13);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (27, 2, 7, 20);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (28, 2, 7, 12);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (29, 2, 9, 17);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (30, 2, 9, 23);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (31, 2, 9, 16);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (32, 2, 8, 15);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (33, 2, 8, 14);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (34, 2, 8, 24);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (35, 2, 5, 9);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (36, 2, 5, 21);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (37, 2, 5, 7);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (38, 2, 6, 11);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (39, 2, 6, 22);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (40, 2, 6, 10);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (41, 1, 12, 28);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (42, 1, 12, 27);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (43, 1, 11, 26);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (44, 1, 11, 25);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (45, 2, 11, 26);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (46, 2, 11, 25);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (47, 2, 12, 28);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (48, 2, 12, 27);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (80, 1, 13, 30);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (81, 1, 13, 29);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (89, 3, 7, 13);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (90, 3, 7, 20);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (91, 3, 7, 12);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (92, 3, 5, 9);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (93, 3, 5, 21);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (94, 3, 5, 7);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (95, 3, 6, 11);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (96, 3, 6, 22);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (97, 3, 6, 10);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (98, 2, 13, 30);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (99, 2, 13, 29);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (100, 1, 13, 33);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (101, 2, 13, 33);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (102, 1, 11, 34);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (103, 1, 12, 35);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (105, 2, 11, 34);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (107, 2, 12, 35);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (108, 2, 10, 18);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (109, 2, 10, 19);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (110, 5, 7, 13);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (111, 5, 7, 20);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (112, 5, 7, 12);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (113, 5, 9, 17);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (114, 5, 9, 23);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (115, 5, 9, 16);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (116, 5, 11, 26);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (117, 5, 11, 34);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (118, 5, 11, 25);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (119, 5, 13, 30);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (120, 5, 13, 33);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (121, 5, 13, 29);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (122, 5, 14, 32);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (123, 5, 14, 36);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (124, 5, 14, 31);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (125, 5, 10, 18);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (126, 5, 10, 19);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (127, 5, 12, 28);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (128, 5, 12, 35);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (129, 5, 12, 27);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (130, 5, 5, 9);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (131, 5, 5, 21);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (132, 5, 5, 7);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (133, 5, 6, 11);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (134, 5, 6, 22);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (135, 5, 6, 10);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (136, 5, 8, 15);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (137, 5, 8, 24);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (138, 5, 8, 14);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (139, 5, 16, 38);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (140, 5, 16, 37);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (141, 5, 15, 40);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (142, 5, 15, 39);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (143, 5, 15, 42);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (144, 5, 16, 41);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (148, 1, 15, 40);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (149, 1, 15, 42);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (150, 1, 15, 39);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (151, 5, 7, 43);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (152, 5, 7, 44);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (153, 1, 7, 43);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (154, 1, 7, 44);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (155, 2, 7, 43);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (156, 2, 7, 44);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (157, 3, 7, 44);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (158, 3, 7, 43);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (161, 5, 10, 45);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (165, 1, 10, 45);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (169, 2, 10, 45);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (171, 2, 15, 40);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (172, 2, 15, 42);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (173, 2, 15, 39);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (174, 3, 10, 45);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (175, 3, 10, 18);
INSERT INTO `menu_access` (`id_menu_access`, `usertype_id`, `menu_id`, `submenu_id`) VALUES (176, 3, 10, 19);


#
# TABLE STRUCTURE FOR: peminjaman
#

DROP TABLE IF EXISTS `peminjaman`;

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_peminjaman` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `arsip_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `divisi_id` int(11) NOT NULL,
  `is_kembali` tinyint(1) DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_peminjaman` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_peminjaman`),
  KEY `FK_peminjaman_arsip` (`arsip_id`),
  KEY `FK_peminjaman_users` (`user_id`),
  KEY `FK_peminjaman_divisi` (`divisi_id`),
  KEY `FK_peminjaman_instansi` (`instansi_id`),
  KEY `FK_peminjaman_cabang` (`cabang_id`),
  CONSTRAINT `FK_peminjaman_arsip` FOREIGN KEY (`arsip_id`) REFERENCES `arsip` (`id_arsip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_peminjaman_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_peminjaman_divisi` FOREIGN KEY (`divisi_id`) REFERENCES `divisi` (`id_divisi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_peminjaman_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_peminjaman_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_users`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: pengembalian
#

DROP TABLE IF EXISTS `pengembalian`;

CREATE TABLE `pengembalian` (
  `id_pengembalian` int(11) NOT NULL AUTO_INCREMENT,
  `tgl_kembali` date NOT NULL,
  `peminjaman_id` int(11) NOT NULL,
  `arsip_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `divisi_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_pengembalian` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pengembalian`),
  KEY `FK_pengembalian_peminjaman` (`peminjaman_id`),
  KEY `FK_pengembalian_arsip` (`arsip_id`),
  KEY `FK_pengembalian_users` (`user_id`),
  KEY `FK_pengembalian_divisi` (`divisi_id`),
  KEY `FK_pengembalian_instansi` (`instansi_id`),
  KEY `FK_pengembalian_cabang` (`cabang_id`),
  CONSTRAINT `FK_pengembalian_arsip` FOREIGN KEY (`arsip_id`) REFERENCES `arsip` (`id_arsip`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pengembalian_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pengembalian_divisi` FOREIGN KEY (`divisi_id`) REFERENCES `divisi` (`id_divisi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pengembalian_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pengembalian_peminjaman` FOREIGN KEY (`peminjaman_id`) REFERENCES `peminjaman` (`id_peminjaman`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_pengembalian_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_users`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

#
# TABLE STRUCTURE FOR: rak
#

DROP TABLE IF EXISTS `rak`;

CREATE TABLE `rak` (
  `id_rak` int(11) NOT NULL AUTO_INCREMENT,
  `rak_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete_rak` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_rak`),
  KEY `FK_rak_instansi` (`instansi_id`),
  KEY `FK_rak_cabang` (`cabang_id`),
  CONSTRAINT `FK_rak_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_rak_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `rak` (`id_rak`, `rak_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_rak`, `deleted_by`, `deleted_at`) VALUES (1, '1', 1, 1, '2020-12-17 07:50:25', 'muhazmi', '', NULL, 0, NULL, NULL);
INSERT INTO `rak` (`id_rak`, `rak_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_rak`, `deleted_by`, `deleted_at`) VALUES (2, '1', 2, 2, '2020-12-17 07:34:04', 'adminpbmt', '', NULL, 0, NULL, NULL);
INSERT INTO `rak` (`id_rak`, `rak_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_rak`, `deleted_by`, `deleted_at`) VALUES (3, '1', 4, 5, '2020-12-17 13:34:56', 'superadminmmj01', '', NULL, 0, NULL, NULL);
INSERT INTO `rak` (`id_rak`, `rak_name`, `instansi_id`, `cabang_id`, `created_at`, `created_by`, `modified_by`, `modified_at`, `is_delete_rak`, `deleted_by`, `deleted_at`) VALUES (4, '1', 2, 4, '2020-12-25 07:55:15', 'adminmaal', '', NULL, 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: submenu
#

DROP TABLE IF EXISTS `submenu`;

CREATE TABLE `submenu` (
  `id_submenu` int(11) NOT NULL AUTO_INCREMENT,
  `submenu_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `submenu_function` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `order_no` tinyint(4) NOT NULL,
  PRIMARY KEY (`id_submenu`),
  KEY `FK_submenu_menu` (`menu_id`),
  CONSTRAINT `FK_submenu_menu` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (7, 'Tambah Peminjaman', 'create', 5, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (9, 'Data Peminjaman', 'index', 5, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (10, 'Tambah Pengembalian', 'create', 6, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (11, 'Data Pengembalian', 'index', 6, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (12, 'Tambah Arsip', 'create', 7, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (13, 'Data Arsip', 'index', 7, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (14, 'Tambah Rak', 'create', 8, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (15, 'Data Rak', 'index', 8, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (16, 'Tambah Baris', 'create', 9, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (17, 'Data Baris', 'index', 9, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (18, 'Laporan Peminjaman', 'peminjaman', 10, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (19, 'Laporan Pengembalian', 'pengembalian', 10, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (20, 'Recycle Bin', 'deleted_list', 7, 5);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (21, 'Recycle Bin', 'deleted_list', 5, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (22, 'Recycle Bin', 'deleted_list', 6, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (23, 'Recycle Bin', 'deleted_list', 9, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (24, 'Recycle Bin', 'deleted_list', 8, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (25, 'Tambah Box', 'create', 11, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (26, 'Data Box', 'index', 11, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (27, 'Tambah Map', 'create', 12, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (28, 'Data Map', 'index', 12, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (29, 'Tambah Divisi', 'create', 13, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (30, 'Data Divisi', 'index', 13, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (31, 'Tambah Instansi', 'create', 14, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (32, 'Data Instansi', 'index', 14, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (33, 'Recycle Bin', 'deleted_list', 13, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (34, 'Recycle Bin', 'deleted_list', 11, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (35, 'Recycle Bin', 'deleted_list', 12, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (36, 'Recycle Bin', 'deleted_list', 14, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (37, 'Tambah Cabang', 'create', 16, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (38, 'Data Cabang', 'index', 16, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (39, 'Tambah Lokasi Arsip', 'create', 15, 1);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (40, 'Data Lokasi Arsip', 'index', 15, 2);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (41, 'Recycle Bin', 'deleted_list', 16, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (42, 'Recycle Bin', 'deleted_list', 15, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (43, 'Data Arsip Aktif', 'aktif', 7, 3);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (44, 'Data Arsip InAktif', 'inaktif', 7, 4);
INSERT INTO `submenu` (`id_submenu`, `submenu_name`, `submenu_function`, `menu_id`, `order_no`) VALUES (45, 'Laporan Arsip', 'arsip', 10, 3);


#
# TABLE STRUCTURE FOR: template
#

DROP TABLE IF EXISTS `template`;

CREATE TABLE `template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `template` (`id`, `name`, `value`) VALUES (1, 'Layout', 'fixed');
INSERT INTO `template` (`id`, `name`, `value`) VALUES (2, 'Skins', 'skin-blue-light');


#
# TABLE STRUCTURE FOR: tokens
#

DROP TABLE IF EXISTS `tokens`;

CREATE TABLE `tokens` (
  `id_tokens` int(11) NOT NULL AUTO_INCREMENT,
  `instansi_id` int(11) DEFAULT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_name` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id_tokens`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tokens` (`id_tokens`, `instansi_id`, `user_id`, `email`, `folder_name`, `token`, `created_at`, `created_by`, `modified_by`, `modified_at`) VALUES (1, 1, '1', 'wakpedwakyeng@gmail.com', 'GrandAdmin Corp LOCAL', '{\"access_token\":\"ya29.a0AfH6SMCf6HSt3202jyrhD4ebyIAkmjPWMowHfU5qL0o-ViAr86SnsnaESopRT0Vzt9zYKkGZHMaU8C05iD-eEHlhL6f8ioUoXeL-SOCeZVtz28dk4RqqcENs-iKwyJNsNkhoZJh2B23KzP_wLEm2jyGszJYDTNhxpB_sy1sUjKA\",\"expires_in\":3599,\"refresh_token\":\"1\\/\\/0gL36cigIQ-AXCgYIARAAGBASNwF-L9IrEKYmctoLkL7E3wIPDXZrakWRivHt_pJQir-xUCI1q16jbeGzDgrahUBNxdooPWzohWo\",\"scope\":\"openid https:\\/\\/www.googleapis.com\\/auth\\/userinfo.profile https:\\/\\/www.googleapis.com\\/auth\\/drive https:\\/\\/www.googleapis.com\\/auth\\/userinfo.email\",\"token_type\":\"Bearer\",\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImUxOTdiZjJlODdiZDE5MDU1NzVmOWI2ZTVlYjQyNmVkYTVkNTc0ZTMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTc3NTMwODU0ODgyNDI0OTM0MzMiLCJlbWFpbCI6Indha3BlZHdha3llbmdAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJqTWlGSHRGLXJxbnR5d1QzS3FfSkNRIiwibmFtZSI6Ildha3BlZCB3YWt5ZW5nIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS8tUE1qZFFQbi1zeTgvQUFBQUFBQUFBQUkvQUFBQUFBQUFBQUEvQU1adXVjbWtZd28xeDlaSFh1c0pxLXFMalMyNzRYUlBvdy9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiV2FrcGVkIiwiZmFtaWx5X25hbWUiOiJ3YWt5ZW5nIiwibG9jYWxlIjoiZW4tR0IiLCJpYXQiOjE2MDgxNjYyODAsImV4cCI6MTYwODE2OTg4MH0.G71gGdknWqk-wtVGVP8bVMEjo8Hqg7lEB9eFEGohvtkJxeUz8PsMIEpfTcjpeDUpIfZq-IPJPyvY0WQH77PEOPr0wqBR1YD5kv3jvnR9FPgvVaxd721jQLK9gNlxFC4ypjFKIs7VApy1GSsEtgj99Ysybyy40Am5NkPjsSGHhfzP9e_qKx-SJArwmxDqOMHpHhQ9xp4xEV7D0Fr82LTRqv_FEQlC1nRdRSkozAWPlbgZNXwXmdhHUp0bWvPujPgzB58dcWbO-1yh08cPhvzNBJ4q6EYhkjfQwugCsMx7wcFv_y47mC1x2PH03UV4Ms1QJWIzW_hdu-OZFQRx_rv2Gg\",\"created\":1608166280}', '2020-12-17 07:51:20', '', 'muhazmi', '2020-12-17 07:51:37');
INSERT INTO `tokens` (`id_tokens`, `instansi_id`, `user_id`, `email`, `folder_name`, `token`, `created_at`, `created_by`, `modified_by`, `modified_at`) VALUES (3, 2, '2', 'arsippbmt@gmail.com', 'ARSIP PBMT', '{\"access_token\":\"ya29.a0AfH6SMBxueh718YqmJTGab3LQitJelIxM11vl-34Nwf1Ez68VrMwOTVAaEVMF5QfEJzOCRbhUSvHmU6jW4OVfUkxH28oXLdqyOVjWw_1rXVpyT0cHXo72cV4JzbzRbtaJZ2kxbghfr2z1fxINxibaZ4LCnrk6k-v9i0UG3rmQeE\",\"expires_in\":3599,\"refresh_token\":\"1\\/\\/0gFh3AjaXeWRnCgYIARAAGBASNwF-L9Irogt_vyELyhAmC4Aug7U1g7-VDetX_7uOEeS5lCYH90-3yUnc1CrcQPW0p5ac_5BhjXQ\",\"scope\":\"https:\\/\\/www.googleapis.com\\/auth\\/drive openid https:\\/\\/www.googleapis.com\\/auth\\/userinfo.email https:\\/\\/www.googleapis.com\\/auth\\/userinfo.profile\",\"token_type\":\"Bearer\",\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImUxOTdiZjJlODdiZDE5MDU1NzVmOWI2ZTVlYjQyNmVkYTVkNTc0ZTMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTQwMTI5NTQ1NjQ4MTMzNTQwOTgiLCJlbWFpbCI6ImFyc2lwcGJtdEBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiYXRfaGFzaCI6IjZ4eXR0cG5vSGxvNFBRQVcyQjJCZ0EiLCJuYW1lIjoiQXJzaXAgcGJtdCIsInBpY3R1cmUiOiJodHRwczovL2xoNS5nb29nbGV1c2VyY29udGVudC5jb20vLU81al9odzUybDU4L0FBQUFBQUFBQUFJL0FBQUFBQUFBQUFBL0FNWnV1Y205eURfNURfVTIyX21mX1p0T1A1d2RQUUh5cUEvczk2LWMvcGhvdG8uanBnIiwiZ2l2ZW5fbmFtZSI6IkFyc2lwIiwiZmFtaWx5X25hbWUiOiJwYm10IiwibG9jYWxlIjoiaWQiLCJpYXQiOjE2MDgxODk4NjYsImV4cCI6MTYwODE5MzQ2Nn0.k5z1ow4eRGZgnX-bWR-qql2C0XwufcixIVFEpOd6ki6OsC8dNZT0ZaSBzqP1Vs25WUd2yt8sBpYvHyxDrVXv8Mkzj_gvd67JX0Yp8GpNzK76_5j6Hjs21maD8MduAwYy07AbcVuCpQYNkoL9BRFhYQ7NSQ1ZSsadaHzbPbAZ7_t3nC0KYvimzfxnaUQSa-q0BZ_LvJciB0DMi2uN70q9nRHYu1d13XtNljgd5AjZ0fk5J3IZaYa4jYiEVWcpffxumrJf37c1G0VYk2tL4XCgZY12e6kKqxxbXr5m2aCAUEjhQxzm5wzKyflXT9d3SuS2oWCJyIKSC74PSX_CJUZSGQ\",\"created\":1608189866}', '2020-12-17 07:24:26', '', 'jondhy', '2020-12-17 07:25:13');
INSERT INTO `tokens` (`id_tokens`, `instansi_id`, `user_id`, `email`, `folder_name`, `token`, `created_at`, `created_by`, `modified_by`, `modified_at`) VALUES (4, 4, '1', 'wakpedwakyeng@gmail.com', 'MMJ', '{\"access_token\":\"ya29.a0AfH6SMBiUozlk2jHvuVkCq89t4-9y-ZpBEoEw9mEqsTQ7iHdQNnv-O-kZVXg5yjoFaYi9ZOizr0LzwJiUuyqI5uDJ2P9VhJUZ9gmuvXIalnbR1upx490v6tuH75ft2zj_7_VwDi_QguUdBS9fCI3jMFF3CbHAJ4Js06UMBoTkFY\",\"expires_in\":3599,\"refresh_token\":\"1\\/\\/0glR6sR5tOYSvCgYIARAAGBASNwF-L9Irg_k5mAKtHsG0a5QEFInYj1G7UOl6z3JyCWloZSnrx_w2GW7eDzdvji6-nemvJ-1dbeI\",\"scope\":\"https:\\/\\/www.googleapis.com\\/auth\\/userinfo.email https:\\/\\/www.googleapis.com\\/auth\\/userinfo.profile openid https:\\/\\/www.googleapis.com\\/auth\\/drive\",\"token_type\":\"Bearer\",\"id_token\":\"eyJhbGciOiJSUzI1NiIsImtpZCI6ImUxOTdiZjJlODdiZDE5MDU1NzVmOWI2ZTVlYjQyNmVkYTVkNTc0ZTMiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiIzMTY2MjE0MTA3NTMtOXJwM3JxcjM5Zms0dGZ2c2RrZ2owMmNoMDRxMGcxZjMuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMTc3NTMwODU0ODgyNDI0OTM0MzMiLCJlbWFpbCI6Indha3BlZHdha3llbmdAZ21haWwuY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImF0X2hhc2giOiJOSFlyamVMUVdHX1pleC0xajY4aXlBIiwibmFtZSI6Ildha3BlZCB3YWt5ZW5nIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS8tUE1qZFFQbi1zeTgvQUFBQUFBQUFBQUkvQUFBQUFBQUFBQUEvQU1adXVjbWtZd28xeDlaSFh1c0pxLXFMalMyNzRYUlBvdy9zOTYtYy9waG90by5qcGciLCJnaXZlbl9uYW1lIjoiV2FrcGVkIiwiZmFtaWx5X25hbWUiOiJ3YWt5ZW5nIiwibG9jYWxlIjoiZW4tR0IiLCJpYXQiOjE2MDgyMTIyMjUsImV4cCI6MTYwODIxNTgyNX0.a1gPrNr0JsPlmYrQ-qKKYslct211IMwTwqJSezeL5G19uFB2lhPZb-cdvlNYNcEiCz03MHIV4VdS8Y12hP45ZSERxJpeb27dj_a4KSCENtD0vsOCOQIpHx6SdW3wgyAUljJlXW6KdHYWVy1A1qEwTX5fab-XoDDW7J4dviBg1yPLZ8u6vTGWPHDJLf_5KyMpOqN0S7DN7kEkruQ-VTnIZ7vokInGDk1dvGNCN3hdN6W269xUl-fu2CcfU2JGeqki0TJkk_qrbD0PSxHt_Tif0VIFDFbbzafVpgpZCrl201f8u24BdzBuyPIFYo20tlRcF9yEl3Ai5WUDy066rf1Kjg\",\"created\":1608212225}', '2020-12-17 13:37:09', '', 'muhazmi', '2020-12-17 13:38:11');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id_users` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instansi_id` int(11) NOT NULL,
  `cabang_id` int(11) NOT NULL,
  `divisi_id` int(11) NOT NULL,
  `birthdate` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `birthplace` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `address` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `usertype_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `photo` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo_thumb` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_add_reg` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_activation` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code_forgotten` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id_users`),
  KEY `FK_users_usertype` (`usertype_id`) USING BTREE,
  KEY `FK_users_instansi` (`instansi_id`) USING BTREE,
  KEY `FK_users_divisi` (`divisi_id`) USING BTREE,
  KEY `FK_users_cabang` (`cabang_id`),
  CONSTRAINT `FK_users_cabang` FOREIGN KEY (`cabang_id`) REFERENCES `cabang` (`id_cabang`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_users_divisi` FOREIGN KEY (`divisi_id`) REFERENCES `divisi` (`id_divisi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_users_instansi` FOREIGN KEY (`instansi_id`) REFERENCES `instansi` (`id_instansi`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_users_usertype` FOREIGN KEY (`usertype_id`) REFERENCES `usertype` (`id_usertype`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (1, 'Muhammad Azmi', 1, 1, 1, '', '', 1, 'xx', '081228289766', 'azmi2793@gmail.com', 'muhazmi', '$2y$10$EaksY1lqF5CVzVSFss9lIexPSLLlhTqZ44ehroRXHs81WpFZl6El.', 5, 1, 'superadmin20200304102956.jpg', 'superadmin20200304102956_thumb.jpg', '::1', NULL, '', '2020-12-25 22:49:20', '', '2019-03-22 08:41:56', 'muhazmi', '2020-12-25 15:49:20', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (2, 'Supriyadi', 1, 1, 1, '', '', 1, '', '082111', 'supriyadi.jondhy@gmail.com', 'jondhy', '$2y$10$GDdyuZLEIbDO4MqJHDFPsegtTXMd6mlm9QElkmBfYBVHGcdWr8qDu', 5, 1, 'jondhy20201217085946.jpg', 'jondhy20201217085946_thumb.jpg', '36.78.59.13', NULL, '', '2020-12-25 15:18:57', 'superadmin', '2020-02-25 02:56:30', 'jondhy', '2020-12-25 08:18:57', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (3, 'PBMT', 2, 2, 2, '12/15/2005', 'YOGYAKARTA', 1, 'YOGYAKARTA', '', 'arsippbmt@gmail.com', 'adminpbmt', '$2y$10$zDags0AlHDniyK0R44XX3.Ybhnh1D5r.nbl3NpSD/LjWEkvyPNn7m', 1, 1, 'adminpbmt20201217142831.jpg', 'adminpbmt20201217142831_thumb.jpg', '114.142.171.43', NULL, NULL, '2020-12-18 05:36:19', 'jondhy', '2020-12-17 07:28:31', 'jondhy', '2020-12-17 22:36:19', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (4, 'eduarsip', 2, 2, 2, '12/29/1999', 'Yogyakarta', 1, 'Yogyakarta', '09876', 'eduarsip21@gmail.com', 'eduarsip', '$2y$10$xxfLJ3jYtan.VGkjS8D66eBi//izCKFLzL6ywUPP..FqATr6CtK9K', 5, 1, 'eduarsip20201217190150.png', 'eduarsip20201217190150_thumb.png', '114.142.168.0', NULL, NULL, '2020-12-17 19:06:06', 'jondhy', '2020-12-17 12:01:50', '', '2020-12-17 12:06:06', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (5, 'admin', 2, 4, 4, '12/22/1991', 'Yogyakarta', 1, 'Yogyakarta', '9808', 'arsippbmtm@gmail.com', 'adminmaal', '$2y$10$SMSYGMMuxrbn3PYGJ2lVK.hrkPLoOZtF7yEd72H52lumvHrqWJqm6', 2, 1, 'adminmaal20201217191509.jpg', 'adminmaal20201217191509_thumb.jpg', '114.142.168.0', NULL, NULL, '2020-12-25 15:17:21', 'adminpbmt', '2020-12-17 12:15:09', 'adminpbmt', '2020-12-25 08:17:21', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (6, 'MasterAdmin MMJ 01', 4, 5, 5, '', '', 1, '', '', 'masteradminmmj01@gmail.com', 'masteradminmmj01', '$2y$10$RDA5uIGBuLn4gvcBppwC/eU6KqLf9YMT4QzAbiW7kZ/6zk8k7q7tG', 1, 1, '', '', '175.158.37.101', NULL, NULL, '2020-12-17 20:38:58', 'muhazmi', '2020-12-17 13:10:12', '', '2020-12-17 13:38:58', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (7, 'Administrator MMJ 01', 4, 5, 5, '', '', 1, '', '', 'administratormmj01@gmail.com', 'administratormmj01', '$2y$10$c583yrU6LO3lVLrbQ9qmX.yvPQmtxCvklpMU6EnNunHd3DYVaz0CW', 3, 1, '', '', '175.158.37.101', NULL, NULL, '2020-12-17 20:42:05', 'masteradminmmj01', '2020-12-17 13:32:52', '', '2020-12-17 13:42:05', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (8, 'Budi Anduk', 4, 5, 6, '', '', 1, '', '', 'budianduk@gmail.com', 'budianduk', '$2y$10$.Jr1io7EDLbIpwh85wNWPO26nyygCCnnsMmyEObH4qiKJPXSXqgk6', 4, 1, '', '', '175.158.37.101', NULL, NULL, NULL, 'masteradminmmj01', '2020-12-17 13:33:37', '', NULL, 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (9, 'SuperAdmin MMJ 01', 4, 5, 6, '', '', 1, '', '', 'superadminmmj01@gmail.com', 'superadminmmj01', '$2y$10$GoP/XyWwuz1l1plxmy7hDeU/ebjeMYK5QpWjvOEIMDLcGF/EinhVW', 2, 1, '', '', '175.158.37.101', NULL, NULL, '2020-12-17 20:34:49', 'masteradminmmj01', '2020-12-17 13:34:05', '', '2020-12-17 13:34:49', 0, NULL, NULL);
INSERT INTO `users` (`id_users`, `name`, `instansi_id`, `cabang_id`, `divisi_id`, `birthdate`, `birthplace`, `gender`, `address`, `phone`, `email`, `username`, `password`, `usertype_id`, `is_active`, `photo`, `photo_thumb`, `ip_add_reg`, `code_activation`, `code_forgotten`, `last_login`, `created_by`, `created_at`, `modified_by`, `modified_at`, `is_delete`, `deleted_by`, `deleted_at`) VALUES (10, 'rosi', 2, 4, 4, '12/22/2020', 'Yogyakarta', 1, 'Yogyakarta', '12342', 'rosimaal@gmail.com', 'rosimaal', '$2y$10$CwtgrrOnm7pJyr8pZ52oreshcGj7y9i228gFajmxx//45xUXEJA8m', 3, 1, 'rosimaal20201218052747.png', 'rosimaal20201218052747_thumb.png', '114.142.171.22', NULL, NULL, '2020-12-18 05:46:08', 'adminmaal', '2020-12-17 22:27:47', '', '2020-12-17 22:46:08', 0, NULL, NULL);


#
# TABLE STRUCTURE FOR: users_data_access
#

DROP TABLE IF EXISTS `users_data_access`;

CREATE TABLE `users_data_access` (
  `id_users_data_access` int(11) NOT NULL AUTO_INCREMENT,
  `data_access_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id_users_data_access`),
  KEY `FK_users_data_access_users` (`user_id`),
  CONSTRAINT `FK_users_data_access_users` FOREIGN KEY (`user_id`) REFERENCES `users` (`id_users`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (6, 1, 2);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (7, 2, 2);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (8, 3, 2);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (9, 4, 2);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (10, 5, 2);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (11, 1, 1);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (12, 2, 1);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (13, 3, 1);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (14, 4, 1);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (15, 5, 1);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (21, 1, 4);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (22, 2, 4);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (23, 3, 4);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (24, 4, 4);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (25, 5, 4);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (26, 1, 3);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (27, 2, 3);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (28, 3, 3);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (29, 4, 3);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (30, 5, 3);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (36, 1, 5);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (37, 2, 5);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (38, 3, 5);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (39, 4, 5);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (40, 5, 5);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (41, 1, 6);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (42, 2, 6);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (43, 3, 6);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (44, 4, 6);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (45, 5, 6);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (46, 1, 7);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (47, 2, 7);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (48, 3, 7);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (49, 4, 7);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (50, 5, 7);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (51, 1, 8);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (52, 2, 8);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (53, 3, 8);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (54, 4, 8);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (55, 5, 8);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (56, 1, 9);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (57, 2, 9);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (58, 3, 9);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (59, 4, 9);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (60, 5, 9);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (61, 1, 10);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (62, 2, 10);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (63, 3, 10);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (64, 4, 10);
INSERT INTO `users_data_access` (`id_users_data_access`, `data_access_id`, `user_id`) VALUES (65, 5, 10);


#
# TABLE STRUCTURE FOR: usertype
#

DROP TABLE IF EXISTS `usertype`;

CREATE TABLE `usertype` (
  `id_usertype` int(11) NOT NULL AUTO_INCREMENT,
  `usertype_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id_usertype`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `usertype` (`id_usertype`, `usertype_name`) VALUES (1, 'MasterAdmin');
INSERT INTO `usertype` (`id_usertype`, `usertype_name`) VALUES (2, 'SuperAdmin');
INSERT INTO `usertype` (`id_usertype`, `usertype_name`) VALUES (3, 'Administrator');
INSERT INTO `usertype` (`id_usertype`, `usertype_name`) VALUES (4, 'Pegawai');
INSERT INTO `usertype` (`id_usertype`, `usertype_name`) VALUES (5, 'GrandAdmin');


SET foreign_key_checks = 1;
